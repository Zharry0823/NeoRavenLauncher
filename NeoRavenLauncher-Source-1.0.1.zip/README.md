# NeoRavenLauncher

为 **NeoRaven**（Minecraft 1.8.9 · Forge 11.15.1.2318 · Mixin 0.7.11）打造的桌面启动器。
深色亚克力界面 + Material Design 3 动效，支持 Windows 与 macOS。

![material](https://img.shields.io/badge/Material-Design%203-FF9BB2) ![electron](https://img.shields.io/badge/Electron-33-2B2E3A)

## 特性

- **深色亚克力窗口**：Windows 11 调用 DWM `acrylic` 材质，macOS 使用 `NSVisualEffectView`，其余环境自动降级为 CSS 玻璃层。
- **Material 原生色板**：18 个取自 MUI 官方 palette 的预设色，默认粉色 `#FF9BB2`，支持自定义取色，实时生效并持久化。
- **一键部署**：自动完成 Java 8 运行时 → Minecraft 1.8.9 原版 → Forge → NeoRaven 客户端注入，带分阶段进度与实时日志。
- **完整设置项**：主题色 / 亚克力浓度 / 动效开关 / 数据根目录 / 游戏目录 / 材质包 / 存档 / 模组 / 截图目录 / Java 路径 / 内存 / JVM 参数 / 分辨率。
- **双平台安装包**：Windows（NSIS，含安装模式、安装路径、许可协议、卸载程序）与 macOS（dmg，含拖拽安装背景）。

## 目录结构

```
electron/            主进程
  main.js            窗口（亚克力/材质）、IPC、单实例
  preload.js         contextBridge 暴露的安全 API
  core/
    settings.js      配置读写（原子写入、目录联动）
    download.js      断点续传下载、并发池、进度节流
    java.js          Java 8 探测与自动下载（Adoptium + 镜像回退）
    vanilla.js       1.8.9 版本 JSON / 类库 / 原生库 / 资源索引
    forge.js         Forge 安装配置解析与依赖部署
    launch.js        启动参数组装与进程管理
src/                 React 渲染层（Vite + MUI 6）
  theme.js           主题与色板
  components/        标题栏、侧栏、启动按钮、日志、玻璃卡片
  pages/             主页 / 外观 / 目录 / 高级 / 关于
build/               图标、许可证、NSIS 自定义片段、macOS entitlements
```

## 开发

```bash
npm install
npm run dev      # 仅渲染层（浏览器预览）
npm start        # 构建渲染层并以 Electron 启动
```

## 打包

```bash
npm run dist:win   # Windows 安装程序 (NSIS) → dist/
npm run dist:mac   # macOS dmg (x64 + arm64) → dist/
```

> `dist:mac` 必须在 macOS 上执行（electron-builder 无法在 Windows 上产出 dmg）。
> 国内网络建议设置镜像：`ELECTRON_MIRROR`、`ELECTRON_BUILDER_BINARIES_MIRROR`（已在 `.npmrc` 中预置）。

## 安装程序行为

- 安装模式页：**为所有用户安装 / 仅为我安装**
- 许可协议页（`build/license.rtf`）
- 安装路径页（可修改）
- 桌面与开始菜单快捷方式、控制面板卸载项、独立卸载程序
- 卸载默认保留用户数据（`deleteAppDataOnUninstall: false`）

## 运行时数据

默认位于 `%APPDATA%/NeoRavenLauncher`（macOS 为 `~/Library/Application Support/NeoRavenLauncher`），
内含 `.minecraft`、`libraries`、`assets`、`runtime/jre8` 与 `launcher-settings.json`。

## 免责声明

本项目仅用于学习与研究，与 Mojang、Microsoft、Hypixel 无任何关联，使用风险自负。
