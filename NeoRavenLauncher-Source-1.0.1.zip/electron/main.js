const { app, BrowserWindow, ipcMain, dialog, shell, nativeTheme } = require('electron')
const path = require('path')
const fs = require('fs')
const fsp = require('fs').promises
const os = require('os')

const { SettingsStore } = require('./core/settings')
const { detectJava } = require('./core/java')
const { launchGame } = require('./core/launch')
const { getHwid, maskHwid } = require('./core/hwid')
const { fetchUsername, pushUsername } = require('./core/cloud')
const updates = require('./core/updates')
const { applyIconColor } = require('./core/icon')

const isMac = process.platform === 'darwin'
const isWin = process.platform === 'win32'
const osBuild = Number((os.release().split('.')[2] || 0))
const SUPPORTS_ACRYLIC = isWin && osBuild >= 22000

let win = null
let store = null
let gameChild = null
let lastJavaInfo = null
let hwid = ''
let updateState = { releases: [], current: '', latest: '', updated: false, checking: true, error: null }

/* 启动阶段日志：设置 NRL_BOOTLOG=1 时写入 userData/boot.log，便于排查打包环境问题 */
function bootLog(message) {
  if (!process.env.NRL_BOOTLOG) return
  try {
    fs.appendFileSync(path.join(app.getPath('userData'), 'boot.log'), `${new Date().toISOString()} ${message}\n`)
  } catch {
    /* 忽略 */
  }
}

app.setName('NeoRavenLauncher')
if (process.platform === 'win32') app.setAppUserModelId('com.neoraven.launcher')

const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore()
      win.focus()
    }
  })
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload)
}

function materialMode() {
  if (SUPPORTS_ACRYLIC) return 'acrylic'
  if (isMac) return 'vibrancy'
  return 'blur'
}

function createWindow() {
  nativeTheme.themeSource = 'dark'

  win = new BrowserWindow({
    width: 920,
    height: 560,
    minWidth: 820,
    minHeight: 500,
    show: false,
    frame: false,
    roundedCorners: true,
    // Windows 11 系统亚克力：窗口本体不能是 layered/transparent，否则 DWM 材质失效
    transparent: SUPPORTS_ACRYLIC ? false : true,
    backgroundColor: SUPPORTS_ACRYLIC ? '#00000000' : '#121014',
    backgroundMaterial: SUPPORTS_ACRYLIC ? 'acrylic' : undefined,
    titleBarStyle: isMac ? 'hiddenInset' : undefined,
    trafficLightPosition: isMac ? { x: 18, y: 22 } : undefined,
    vibrancy: isMac ? 'under-window' : undefined,
    visualEffectState: isMac ? 'active' : undefined,
    title: 'NeoRavenLauncher',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      backgroundThrottling: false
    }
  })

  win.once('ready-to-show', () => {
    bootLog('ready-to-show')
    win.show()
    win.focus()
    if (process.env.NRL_TOPMOST) win.setAlwaysOnTop(true, 'screen-saver')
    // 开发期：NRL_SCROLL=<px> 让内容区滚动到指定位置，便于截图自检
    if (process.env.NRL_SCROLL) {
      setTimeout(() => {
        const px = Number(process.env.NRL_SCROLL) || 0
        win.webContents
          .executeJavaScript(
            `(() => { const el = document.querySelector('.page') || document.querySelector('.content'); if (el) el.scrollTop = ${px}; return !!el })()`
          )
          .catch(() => {})
      }, 900)
    }
    // 开发期：NRL_EVAL=<js> 在页面里执行脚本（仅自检用）
    if (process.env.NRL_EVAL) {
      setTimeout(() => {
        win.webContents.executeJavaScript(process.env.NRL_EVAL).catch((e) => bootLog('eval failed ' + e.message))
      }, 1200)
    }
  })

  win.webContents.on('did-fail-load', (_e, code, desc, url) => {
    bootLog(`did-fail-load ${code} ${desc} ${url}`)
    win.show()
  })
  win.webContents.on('render-process-gone', (_e, details) => {
    bootLog(`render-process-gone ${JSON.stringify(details)}`)
  })
  win.webContents.on('console-message', (_e, level, message, line, source) => {
    bootLog(`console(${level}) ${message} @${source}:${line}`)
  })
  // 兜底：即便渲染进程报错也让窗口可见，避免“无窗口”状态
  setTimeout(() => {
    if (win && !win.isDestroyed() && !win.isVisible()) {
      bootLog('fallback-show')
      win.show()
    }
  }, 3500)

  const devUrl = process.env.VITE_DEV_SERVER_URL
  const initialPage = process.env.NRL_PAGE ? `?page=${process.env.NRL_PAGE}` : ''
  if (devUrl) {
    win.loadURL(devUrl + initialPage).catch((e) => bootLog('loadURL failed ' + e.message))
  } else {
    const index = path.join(__dirname, '..', 'dist-renderer', 'index.html')
    bootLog('loading ' + index)
    win.loadFile(index, initialPage ? { search: initialPage.slice(1) } : undefined).catch((e) => {
      bootLog('loadFile failed ' + e.message)
      win.show()
    })
  }

  win.on('closed', () => {
    win = null
  })

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url)
    return { action: 'deny' }
  })
}

async function bootstrap() {
  const settings = store.get()
  if (!lastJavaInfo) {
    try {
      lastJavaInfo = await detectJava(settings, settings.rootDir)
    } catch {
      lastJavaInfo = { found: false }
    }
  }
  return {
    settings,
    firstRun: !settings.userNamed,
    hwid,
    hwidMasked: maskHwid(hwid),
    updateState,
    app: {
      version: app.getVersion(),
      electron: process.versions.electron,
      chrome: process.versions.chrome,
      node: process.versions.node,
      platform: process.platform,
      arch: process.arch,
      osBuild,
      material: materialMode(),
      acrylic: SUPPORTS_ACRYLIC,
      isMac,
      pathSep: path.sep
    },
    java: lastJavaInfo
  }
}

/** 启动时：按 HWID 找回用户名（重装/换机识别） */
async function initIdentity() {
  hwid = getHwid()
  const s = store.get()
  if (s.hwid !== hwid) await store.save({ hwid })
  // 旧版本升级：本机已有用户名则视为已命名，不被云端覆盖
  if (!s.userNamed && s.username) {
    await store.save({ userNamed: true })
    return
  }
  if (s.userNamed && s.username) return
  const res = await fetchUsername(hwid)
  bootLog('identity cloud lookup: ' + JSON.stringify(res))
  if (res.ok && res.username) {
    await store.save({ username: res.username, userNamed: true })
    send('settings:changed', store.get())
    send('user:identified', { username: res.username, fromCloud: true })
  }
}

/** 启动时自动检测并应用更新（后台跑，不阻塞窗口） */
async function runUpdateCheck() {
  updateState = { ...updateState, checking: true, error: null }
  send('updates:state', updateState)
  bootLog('update check start')
  // 看门狗：只要还在持续下载就不算超时，静默 120s 才判失败
  let lastBeat = Date.now()
  let guardTimer = null
  const beat = () => {
    lastBeat = Date.now()
  }
  const arm = () => {
    if (guardTimer) clearTimeout(guardTimer)
    guardTimer = setTimeout(() => {
      if (!updateState.checking) return
      if (Date.now() - lastBeat < 60000) return arm()
      updateState = { ...updateState, checking: false, error: '更新检查超时，已跳过（可稍后在设置中重试）' }
      send('updates:state', updateState)
      bootLog('update check watchdog timeout')
    }, 60000)
  }
  arm()
  let result
  try {
    result = await updates.checkAndApply(store, {
      onLog: (line) => send('launch:log', line),
      onProgress: (p) => {
        beat()
        send('updates:state', { ...updateState, checking: true, progress: p })
      }
    })
    bootLog('update check done ' + JSON.stringify({ updated: result.updated, error: result.error, current: result.current }))
  } catch (e) {
    bootLog('update check threw ' + (e && e.message))
    result = { releases: [], current: '', latest: '', updated: false, error: e && e.message }
  } finally {
    if (guardTimer) clearTimeout(guardTimer)
  }
  updateState = {
    releases: result.releases || [],
    current: result.current || '',
    latest: result.latest || '',
    updated: !!result.updated,
    checking: false,
    error: result.error || null
  }
  send('updates:state', updateState)
  send('settings:changed', store.get())
  if (result.updated) {
    send('launch:log', `[update] 已自动更新到 ${result.releases[0] && result.releases[0].name}\n`)
  }
  return updateState
}

function registerIpc() {
  ipcMain.handle('app:bootstrap', async () => bootstrap())

  ipcMain.handle('settings:save', async (_e, patch) => {
    const next = await store.save(patch || {})
    if (patch && patch.username !== undefined && next.userNamed) {
      pushUsername(hwid, next.username).catch(() => {})
    }
    send('settings:changed', next)
    return next
  })

  ipcMain.handle('user:setup', async (_e, username) => {
    const name = String(username || '').trim().slice(0, 16)
    if (!name) return { ok: false, error: '用户名不能为空' }
    const next = await store.save({ username: name, userNamed: true })
    const push = await pushUsername(hwid, name)
    send('settings:changed', next)
    return { ok: true, cloud: push.ok, cloudError: push.error || null }
  })

  ipcMain.handle('user:rename', async (_e, username) => {
    const name = String(username || '').trim().slice(0, 16)
    if (!name) return { ok: false, error: '用户名不能为空' }
    const next = await store.save({ username: name, userNamed: true })
    const push = await pushUsername(hwid, name)
    send('settings:changed', next)
    return { ok: true, cloud: push.ok, cloudError: push.error || null }
  })

  ipcMain.handle('updates:check', async () => runUpdateCheck())

  ipcMain.handle('versions:select', async (_e, tag) => {
    try {
      const r = await updates.selectVersion(store, tag, {
        onLog: (line) => send('launch:log', line),
        onProgress: (p) => send('updates:state', { ...updateState, progress: p })
      })
      updateState = { ...updateState, current: r.tag }
      send('updates:state', updateState)
      send('settings:changed', store.get())
      return { ok: true, ...r }
    } catch (e) {
      return { ok: false, error: e && e.message }
    }
  })

  ipcMain.handle('icon:apply', async (_e, { pngDataUrl, color, silent = false } = {}) => {
    try {
      // 先只做最快的一步：换窗口图标 + 落盘 ico，立即返回，避免 UI 卡顿
      const r = await applyIconColor({
        pngDataUrl,
        color,
        userData: app.getPath('userData'),
        skipShortcuts: true,
        silent
      })
      if (!silent) await store.save({ iconColor: color })
      if (!silent) send('settings:changed', store.get())
      // 桌面/开始菜单快捷方式图标较重（PowerShell），放到后台慢慢刷
      applyIconColor({ pngDataUrl, color, userData: app.getPath('userData'), onlyShortcuts: true })
        .then((s) => send('icon:shortcuts', s))
        .catch(() => {})
      return { ok: true, ...r }
    } catch (e) {
      return { ok: false, error: e && e.message }
    }
  })

  ipcMain.handle('dialog:folder', async (_e, { title, current } = {}) => {
    const res = await dialog.showOpenDialog(win, {
      title: title || '选择文件夹',
      defaultPath: current && fs.existsSync(current) ? current : undefined,
      properties: ['openDirectory', 'createDirectory']
    })
    if (res.canceled || !res.filePaths.length) return null
    return res.filePaths[0]
  })

  ipcMain.handle('dialog:javafile', async () => {
    const res = await dialog.showOpenDialog(win, {
      title: '选择 java 可执行文件',
      properties: ['openFile'],
      filters:
        process.platform === 'win32'
          ? [{ name: 'Java', extensions: ['exe'] }]
          : [{ name: 'All files', extensions: ['*'] }]
    })
    if (res.canceled || !res.filePaths.length) return null
    return res.filePaths[0]
  })

  ipcMain.handle('java:detect', async (_e, customPath) => {
    const settings = { ...store.get(), javaPath: customPath || '' }
    const info = await detectJava(settings, settings.rootDir)
    if (info && info.path) lastJavaInfo = info
    return info
  })

  ipcMain.handle('shell:open', async (_e, target) => {
    if (!target) return { ok: false }
    try {
      await fsp.mkdir(target, { recursive: true })
    } catch {
      /* 忽略 */
    }
    const err = await shell.openPath(target)
    return { ok: !err, error: err || null }
  })

  ipcMain.handle('mods:scan', async () => {
    const dir = store.get().modsDir
    try {
      const files = await fsp.readdir(dir, { withFileTypes: true })
      const items = []
      for (const f of files) {
        if (!f.isFile() || !f.name.toLowerCase().endsWith('.jar')) continue
        const st = await fsp.stat(path.join(dir, f.name))
        items.push({ name: f.name, size: st.size, mtime: st.mtimeMs })
      }
      items.sort((a, b) => b.mtime - a.mtime)
      return { dir, count: items.length, items }
    } catch {
      return { dir, count: 0, items: [] }
    }
  })

  ipcMain.handle('launch:start', async () => {
    if (gameChild) return { ok: false, error: '游戏已在运行中' }
    const settings = store.get()
    if (!settings.username || !settings.username.trim()) {
      return { ok: false, error: '请先填写游戏用户名' }
    }
    try {
      send('launch:log', `\n[launcher] === NeoRavenLauncher ${app.getVersion()} ===\n`)
      const child = await launchGame(settings, {
        onLog: (line) => send('launch:log', line),
        onState: (s) => send('launch:state', s)
      })
      gameChild = child
      child.on('exit', () => {
        gameChild = null
      })
      await store.save({ lastLaunch: new Date().toISOString() })
      // 仅当用户显式开启「启动后隐藏启动器」才最小化；默认保持窗口可见
      if (settings.closeOnLaunch) win && win.minimize()
      return { ok: true }
    } catch (e) {
      const message = e && e.message ? e.message : String(e)
      send('launch:state', { phase: 'error', percent: 0, detail: message, running: false, error: message })
      send('launch:log', `[launcher] 错误: ${message}\n`)
      gameChild = null
      return { ok: false, error: message }
    }
  })

  ipcMain.handle('launch:cancel', async () => {
    if (gameChild) {
      try {
        gameChild.kill()
      } catch {
        /* 忽略 */
      }
      gameChild = null
      send('launch:state', { phase: 'idle', percent: 0, detail: '已取消启动', running: false })
      return { ok: true }
    }
    return { ok: false }
  })

  ipcMain.handle('win:minimize', () => win && win.minimize())
  ipcMain.handle('win:maximize', () => {
    if (!win) return false
    if (win.isMaximized()) win.unmaximize()
    else win.maximize()
    return win.isMaximized()
  })
  ipcMain.handle('win:close', () => win && win.close())
}

app.whenReady().then(async () => {
  bootLog('app ready')
  store = new SettingsStore(app.getPath('userData'))
  await store.load()
  bootLog('settings loaded from ' + store.file)
  registerIpc()
  bootLog('ipc registered')

  try {
    await initIdentity()
  } catch (e) {
    bootLog('initIdentity failed ' + (e && e.message))
  }

  try {
    createWindow()
    bootLog('window created')
  } catch (e) {
    bootLog('createWindow threw ' + (e && e.stack))
    throw e
  }

  // 后台检测更新并自动应用
  runUpdateCheck().catch((e) => {
    bootLog('update check failed ' + (e && e.message))
  })

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (!isMac) app.quit()
})

app.on('before-quit', () => {
  if (gameChild) {
    try {
      gameChild.kill()
    } catch {
      /* 忽略 */
    }
  }
})
