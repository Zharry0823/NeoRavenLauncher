const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')
const AdmZip = require('adm-zip')
const { ensureDir, exists, download, runPool, makeTicker } = require('./download')
const { mavenToPath, VERSION } = require('./vanilla')

const FORGE_VERSION = '1.8.9-11.15.1.2318-1.8.9'
const FORGE_BASE = `https://maven.minecraftforge.net/net/minecraftforge/forge/${FORGE_VERSION}`
const INSTALLER_URL = `${FORGE_BASE}/forge-${FORGE_VERSION}-installer.jar`
const UNIVERSAL_URL = `${FORGE_BASE}/forge-${FORGE_VERSION}-universal.jar`
const MOJANG_MAVEN = 'https://libraries.minecraft.net/'
const FORGE_MAVEN = 'https://maven.minecraftforge.net/'
const MAVEN_CENTRAL = 'https://repo1.maven.org/maven2/'

function libBaseUrls(lib) {
  if (lib.url) return [lib.url.endsWith('/') ? lib.url : lib.url + '/']
  if (lib.name.startsWith('net.minecraft:')) return [MOJANG_MAVEN, FORGE_MAVEN, MAVEN_CENTRAL]
  // Forge 1.8.9 的部分依赖（例如 lzma:lzma）只存在于 Mojang 仓库，需要按序回退
  return [FORGE_MAVEN, MOJANG_MAVEN, MAVEN_CENTRAL]
}

function libRelPath(name) {
  const [coords] = name.split('@')
  const parts = coords.split(':')
  if (parts[1] === 'forge' && parts.length === 3) return mavenToPath(`${name}:universal`)
  return mavenToPath(name)
}

async function readProfile(installerJar) {
  const zip = new AdmZip(installerJar)
  const entry = zip.getEntry('install_profile.json')
  if (!entry) throw new Error('Forge 安装器缺少 install_profile.json')
  return JSON.parse(entry.getData().toString('utf8'))
}

async function ensureForge(root, onProgress = () => {}) {
  const cacheDir = path.join(root, 'cache')
  await ensureDir(cacheDir)
  const installer = path.join(cacheDir, `forge-${FORGE_VERSION}-installer.jar`)

  onProgress({ stage: 'forge', percent: 0, detail: '正在获取 Forge 安装配置…' })
  await download(INSTALLER_URL, installer, { retries: 4 })

  const profile = await readProfile(installer)
  const versionInfo = profile.versionInfo
  if (!versionInfo) throw new Error('Forge 安装配置格式异常')
  const forgeId = versionInfo.id

  const versionDir = path.join(root, 'versions', forgeId)
  await ensureDir(versionDir)
  await fsp.writeFile(path.join(versionDir, `${forgeId}.json`), JSON.stringify(versionInfo, null, 2), 'utf8')

  const libs = (versionInfo.libraries || []).filter((l) => l.clientreq !== false)
  const tasks = []
  for (const lib of libs) {
    const rel = libRelPath(lib.name)
    const dest = path.join(root, 'libraries', rel)
    tasks.push({ urls: libBaseUrls(lib).map((b) => b + rel), dest, name: lib.name })
  }

  let done = 0
  const warnings = []
  const tick = makeTicker(() => onProgress({ stage: 'forge', percent: (done / tasks.length) * 100, detail: `正在安装 Forge 组件 ${done}/${tasks.length}` }))
  await runPool(tasks, 8, async (t) => {
    let lastError = null
    for (const url of t.urls) {
      try {
        await download(url, t.dest, { retries: 2 })
        lastError = null
        break
      } catch (e) {
        lastError = e
      }
    }
    if (lastError) warnings.push(`${t.name}: ${lastError.message}`)
    done++
    tick()
  })

  // 兜底：universal jar 必须存在
  const universalRel = libRelPath(`net.minecraftforge:forge:${FORGE_VERSION}`)
  const universal = path.join(root, 'libraries', universalRel)
  if (!(await exists(universal))) {
    await download(UNIVERSAL_URL, universal, { retries: 4 })
  }

  onProgress({ stage: 'forge', percent: 100, detail: 'Forge 组件就绪' })
  return { versionInfo, forgeId, universal, warnings }
}

module.exports = { ensureForge, FORGE_VERSION, FORGE_BASE }
