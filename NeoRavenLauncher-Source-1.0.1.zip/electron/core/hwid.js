const os = require('os')
const crypto = require('crypto')

/**
 * 稳定的本机硬件标识（HWID），纯 Node 实现（不依赖 reg/wmic/外部命令）。
 * 信号：平台 + 主机名 + 首块物理网卡 MAC + CPU 型号 + 内存大小。
 * 输出 sha256 前 24 位十六进制（不可逆，不泄露原始硬件信息）。
 */
function firstMac() {
  const ifaces = os.networkInterfaces()
  for (const name of Object.keys(ifaces)) {
    if (/^(lo|Loopback|isatap|Teredo)/i.test(name)) continue
    for (const item of ifaces[name] || []) {
      const mac = item && item.mac
      if (mac && mac !== '00:00:00:00:00:00' && !item.internal) return mac.toLowerCase()
    }
  }
  return ''
}

function getHwid() {
  const cpu = os.cpus()[0]
  const raw = [
    process.platform,
    os.hostname(),
    firstMac(),
    cpu ? cpu.model : '',
    String(os.totalmem())
  ].join('|')
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 24)
}

/** 只显示前后几位，界面用 */
function maskHwid(hwid) {
  if (!hwid || hwid.length < 12) return hwid || ''
  return `${hwid.slice(0, 6)}…${hwid.slice(-4)}`
}

module.exports = { getHwid, maskHwid }
