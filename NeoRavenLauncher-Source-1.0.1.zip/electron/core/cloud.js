/**
 * 用户名 ↔ 机器码 云端注册表（WorkBuddy 云服务数据库 nr_users 表）。
 * 本地优先：设置里始终有可用用户名；云端用于重装/换机后按 HWID 找回。
 */
const CLOUD_CONFIG = {
  endpoint: 'https://neoraven-launcher.app.workbuddy.host',
  publishableKey: 'wbpk_BZKY8IDtutNX4t7E70racB_tN141EBW46j5u7AgFa1XRJKX9j1IGEzJ'
}

let client = null

function cloud() {
  if (!client) {
    // eslint-disable-next-line import/no-extraneous-dependencies
    const { createWorkBuddyCloud } = require('@tencent-ai/workbuddy-cloud-sdk')
    client = createWorkBuddyCloud({
      endpoint: CLOUD_CONFIG.endpoint,
      publishableKey: CLOUD_CONFIG.publishableKey
    })
  }
  return client
}

function errText(error) {
  if (!error) return ''
  if (typeof error === 'string') return error
  return error.error_description || error.message || error.error || JSON.stringify(error)
}

/** 按机器码取用户名；返回 { ok, username|null, error } */
async function fetchUsername(hwid) {
  // 调试开关：NRL_NO_CLOUD=1 时跳过云端查找（用于首次启动界面验证）
  if (process.env.NRL_NO_CLOUD) return { ok: true, username: null }
  try {
    const res = await cloud().database.from('nr_users').select('username').eq('hwid', hwid).maybeSingle()
    if (res && res.error) return { ok: false, error: errText(res.error) }
    const row = res && res.data
    return { ok: true, username: row && row.username ? row.username : null }
  } catch (e) {
    return { ok: false, error: errText(e) }
  }
}

/** 上传 / 更新 用户名 + 机器码 */
async function pushUsername(hwid, username) {
  try {
    const res = await cloud()
      .database.from('nr_users')
      .upsert({ hwid, username, updated_at: new Date().toISOString() }, { onConflict: 'hwid' })
    if (res && res.error) return { ok: false, error: errText(res.error) }
    return { ok: true }
  } catch (e) {
    return { ok: false, error: errText(e) }
  }
}

module.exports = { fetchUsername, pushUsername, CLOUD_CONFIG }
