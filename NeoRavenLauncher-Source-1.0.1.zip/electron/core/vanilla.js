const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')
const AdmZip = require('adm-zip')
const { ensureDir, exists, sizeOf, download, getJson, runPool, makeTicker } = require('./download')

const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json'
const RESOURCES_BASE = 'https://resources.download.minecraft.net'
const VERSION = '1.8.9'

function osName() {
  if (process.platform === 'win32') return 'windows'
  if (process.platform === 'darwin') return 'osx'
  return 'linux'
}

function archName() {
  return process.arch === 'x64' || process.arch === 'arm64' ? '64' : '32'
}

function ruleAllows(rules) {
  if (!Array.isArray(rules) || rules.length === 0) return true
  let allowed = false
  for (const rule of rules) {
    let match = true
    if (rule.os) {
      if (rule.os.name && rule.os.name !== osName()) match = false
      if (rule.os.arch && !new RegExp(rule.os.arch.replace('x86', 'x86')).test(process.arch)) match = false
      if (rule.os.version && !new RegExp(rule.os.version).test(require('os').release())) match = false
    }
    if (rule.features) match = false
    if (match) allowed = rule.action === 'allow'
  }
  return allowed
}

function mavenToPath(name) {
  const [coords, extRaw] = name.split('@')
  const parts = coords.split(':')
  const [group, artifact, version, classifier] = parts
  const ext = extRaw || 'jar'
  const file = `${artifact}-${version}${classifier ? '-' + classifier : ''}.${ext}`
  return `${group.replace(/\./g, '/')}/${artifact}/${version}/${file}`
}

async function getVersionJson(root, version = VERSION) {
  const versionsDir = path.join(root, 'versions', version)
  const jsonPath = path.join(versionsDir, `${version}.json`)
  await ensureDir(versionsDir)
  if (await exists(jsonPath)) {
    try {
      const cached = JSON.parse(await fsp.readFile(jsonPath, 'utf8'))
      if (cached && cached.libraries) return cached
    } catch {
      /* 重新下载 */
    }
  }
  const manifest = await getJson(MANIFEST_URL)
  const entry = manifest.versions.find((v) => v.id === version)
  if (!entry) throw new Error(`未找到版本 ${version}`)
  const json = await getJson(entry.url)
  await fsp.writeFile(jsonPath, JSON.stringify(json, null, 2), 'utf8')
  return json
}

async function installLibraries(root, versionJson, onProgress) {
  const libRoot = path.join(root, 'libraries')
  const tasks = []
  for (const lib of versionJson.libraries) {
    if (!ruleAllows(lib.rules)) continue
    const artifact = lib.downloads && lib.downloads.artifact
    if (!artifact) continue
    const rel = artifact.path || mavenToPath(lib.name)
    tasks.push({ url: artifact.url, dest: path.join(libRoot, rel), name: lib.name })
  }
  let done = 0
  const tick = makeTicker(() => onProgress({ stage: 'libraries', done, total: tasks.length }))
  await runPool(tasks, 8, async (t) => {
    await download(t.url, t.dest, { minSize: 1 })
    done++
    tick()
  })
  onProgress({ stage: 'libraries', done: tasks.length, total: tasks.length })
}

async function installClientJar(root, versionJson, onProgress) {
  const dir = path.join(root, 'versions', VERSION)
  const jar = path.join(dir, `${VERSION}.jar`)
  const url = versionJson.downloads && versionJson.downloads.client && versionJson.downloads.client.url
  if (!url) throw new Error('版本信息缺少 client.jar 下载地址')
  onProgress({ stage: 'client', done: 0, total: 1 })
  await download(url, jar, { retries: 4 })
  onProgress({ stage: 'client', done: 1, total: 1 })
  return jar
}

async function installNatives(root, versionJson, onProgress) {
  const nativesDir = path.join(root, 'versions', VERSION, 'natives')
  const marker = path.join(nativesDir, '.complete')
  if (await exists(marker)) return nativesDir
  await ensureDir(nativesDir)

  const os_ = osName()
  const arch = archName()
  const tasks = []
  for (const lib of versionJson.libraries) {
    if (!ruleAllows(lib.rules)) continue
    if (!lib.natives || !lib.natives[os_]) continue
    const classifier = lib.natives[os_].replace('${arch}', arch)
    const art = lib.downloads && lib.downloads.classifiers && lib.downloads.classifiers[classifier]
    if (!art) continue
    tasks.push({ url: art.url, dest: path.join(root, 'libraries', art.path || mavenToPath(lib.name)), name: classifier })
  }
  let done = 0
  onProgress({ stage: 'natives', done: 0, total: tasks.length })
  await runPool(tasks, 6, async (t) => {
    await download(t.url, t.dest)
    const zip = new AdmZip(t.dest)
    for (const entry of zip.getEntries()) {
      if (entry.isDirectory) continue
      if (entry.entryName.includes('/') || entry.entryName.includes('\\')) continue
      if (!/\.(dll|so|dylib|jnilib)$/i.test(entry.entryName)) continue
      fs.writeFileSync(path.join(nativesDir, entry.entryName), entry.getData())
    }
    done++
    onProgress({ stage: 'natives', done, total: tasks.length })
  })
  await fsp.writeFile(marker, new Date().toISOString(), 'utf8')
  return nativesDir
}

async function installAssets(root, versionJson, onProgress) {
  const assetsRoot = path.join(root, 'assets')
  const index = versionJson.assetIndex
  if (!index) throw new Error('版本信息缺少 assetIndex')
  const indexDir = path.join(assetsRoot, 'indexes')
  await ensureDir(indexDir)
  const indexPath = path.join(indexDir, `${index.id}.json`)
  await download(index.url, indexPath, { retries: 4 })
  const data = JSON.parse(await fsp.readFile(indexPath, 'utf8'))
  const entries = Object.values(data.objects || {})

  let totalBytes = 0
  for (const o of entries) totalBytes += o.size || 0
  let done = 0
  let bytes = 0
  const tick = makeTicker(() =>
    onProgress({ stage: 'assets', done, total: entries.length, bytes, totalBytes })
  )
  await runPool(entries, 14, async (obj) => {
    const sub = obj.hash.slice(0, 2)
    const dest = path.join(assetsRoot, 'objects', sub, obj.hash)
    const already = await sizeOf(dest)
    if (already !== obj.size) {
      await download(`${RESOURCES_BASE}/${sub}/${obj.hash}`, dest, { minSize: obj.size })
    }
    bytes += obj.size
    done++
    tick()
  })
  onProgress({ stage: 'assets', done: entries.length, total: entries.length, bytes: totalBytes, totalBytes })
  return { assetsRoot, assetIndexId: index.id }
}

async function ensureVanilla(root, onProgress = () => {}) {
  const versionJson = await getVersionJson(root, VERSION)
  await installLibraries(root, versionJson, onProgress)
  const clientJar = await installClientJar(root, versionJson, onProgress)
  const nativesDir = await installNatives(root, versionJson, onProgress)
  const assets = await installAssets(root, versionJson, onProgress)
  return { versionJson, clientJar, nativesDir, ...assets }
}

module.exports = {
  ensureVanilla,
  getVersionJson,
  ruleAllows,
  mavenToPath,
  osName,
  archName,
  VERSION
}
