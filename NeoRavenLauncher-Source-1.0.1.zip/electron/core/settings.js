const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')
const { ensureDir } = require('./download')

const FILE = 'launcher-settings.json'

const DERIVED = [
  ['gameDir', '.minecraft'],
  ['resourcePacksDir', path.join('.minecraft', 'resourcepacks')],
  ['savesDir', path.join('.minecraft', 'saves')],
  ['modsDir', path.join('.minecraft', 'mods')],
  ['screenshotsDir', path.join('.minecraft', 'screenshots')]
]

/** 默认数据根：优先 D/E/F 盘（C 盘空间紧张），否则回落 userData */
function defaultRoot(userData) {
  if (process.platform === 'win32') {
    for (const drive of ['D:\\', 'E:\\', 'F:\\']) {
      try {
        if (fs.existsSync(drive)) return path.join(drive, 'NeoRaven')
      } catch {
        /* 下一个 */
      }
    }
  } else {
    const home = require('os').homedir()
    const macData = path.join(home, 'NeoRaven')
    return macData
  }
  return userData
}

function defaults(userData) {
  const rootDir = defaultRoot(userData)
  const gameDir = path.join(rootDir, '.minecraft')
  return {
    accent: '#FF9BB2',
    iconColor: '#FF9BB2',
    acrylic: 0.62,
    animations: true,
    density: 1,
    rootDir,
    gameDir,
    resourcePacksDir: path.join(gameDir, 'resourcepacks'),
    savesDir: path.join(gameDir, 'saves'),
    modsDir: path.join(gameDir, 'mods'),
    screenshotsDir: path.join(gameDir, 'screenshots'),
    javaPath: '',
    memoryMb: 4096,
    jvmArgs: '-XX:+UseG1GC -Dfile.encoding=UTF-8',
    fullscreen: false,
    width: 1280,
    height: 720,
    username: '',
    userNamed: false,
    hwid: '',
    clientVersion: '',
    autoUpdate: true,
    closeOnLaunch: false,
    autoJava: true,
    lastLaunch: null
  }
}

class SettingsStore {
  constructor(userData) {
    this.userData = userData
    this.file = path.join(userData, FILE)
    this.data = defaults(userData)
  }

  async load() {
    try {
      const raw = JSON.parse(await fsp.readFile(this.file, 'utf8'))
      // 一次性迁移：旧版本默认数据根在 C 盘 userData 且用户未改过 → 迁到 D:\NeoRaven
      const uncustomizedRoot = !raw.rootDir || path.resolve(raw.rootDir) === path.resolve(this.userData)
      const fresh = defaults(this.userData)
      const win = process.platform === 'win32'
      if (win && uncustomizedRoot && fresh.rootDir !== this.userData) {
        this.data = this.normalize({
          ...fresh,
          ...raw,
          rootDir: fresh.rootDir,
          gameDir: fresh.gameDir,
          resourcePacksDir: fresh.resourcePacksDir,
          savesDir: fresh.savesDir,
          modsDir: fresh.modsDir,
          screenshotsDir: fresh.screenshotsDir
        })
      } else {
        this.data = this.normalize({ ...fresh, ...raw })
      }
    } catch {
      this.data = this.normalize(defaults(this.userData))
    }
    return this.data
  }

  normalize(s) {
    const next = { ...s }
    next.memoryMb = Math.min(32768, Math.max(1024, Number(next.memoryMb) || 4096))
    next.acrylic = Math.min(1, Math.max(0.2, Number(next.acrylic) || 0.62))
    next.density = Math.min(1.15, Math.max(0.9, Number(next.density) || 1))
    next.username = String(next.username || '').slice(0, 16)
    next.userNamed = !!next.userNamed
    next.autoUpdate = next.autoUpdate !== false
    if (!next.accent || !/^#[0-9a-fA-F]{6}$/.test(next.accent)) next.accent = '#FF9BB2'
    // 图标色恒等于主题色（不再单独配置）
    next.iconColor = next.accent
    if (!next.rootDir) next.rootDir = this.userData
    return next
  }

  /** 根目录变更时，把仍位于旧根目录下的派生目录整体迁移 */
  applyRootChange(merged, oldRoot) {
    if (!merged.rootDir) return merged
    const oldResolved = path.resolve(oldRoot)
    const newRoot = merged.rootDir
    if (path.resolve(newRoot) === oldResolved) return merged
    for (const [key] of DERIVED) {
      const cur = merged[key]
      if (typeof cur !== 'string' || !cur) continue
      const curResolved = path.resolve(cur)
      if (curResolved === oldResolved || curResolved.startsWith(oldResolved + path.sep)) {
        merged[key] = path.join(newRoot, path.relative(oldResolved, cur))
      }
    }
    return merged
  }

  async save(patch = {}) {
    const oldRoot = this.data.rootDir
    let merged = { ...this.data, ...patch }
    if (patch.rootDir) merged = this.applyRootChange(merged, oldRoot)
    this.data = this.normalize(merged)
    await ensureDir(this.userData)
    const tmp = this.file + '.tmp'
    await fsp.writeFile(tmp, JSON.stringify(this.data, null, 2), 'utf8')
    await fsp.rename(tmp, this.file)
    return this.data
  }

  get() {
    return this.data
  }
}

module.exports = { SettingsStore, defaults }
