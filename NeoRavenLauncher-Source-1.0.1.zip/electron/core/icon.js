const fs = require('fs')
const path = require('path')
const { execFile } = require('child_process')
const { nativeImage, BrowserWindow, app } = require('electron')

/** PNG 数据 → 单帧 PNG-in-ICO（Win Vista+ 标准） */
function pngToIco(pngBuf) {
  const header = Buffer.alloc(6)
  header.writeUInt16LE(0, 0) // reserved
  header.writeUInt16LE(1, 2) // type = icon
  header.writeUInt16LE(1, 4) // count
  const entry = Buffer.alloc(16)
  entry.writeUInt8(0, 0) // 0 ⇒ 256px
  entry.writeUInt8(0, 1)
  entry.writeUInt8(0, 2)
  entry.writeUInt8(0, 3)
  entry.writeUInt16LE(1, 4) // planes
  entry.writeUInt16LE(32, 6) // bitcount
  entry.writeUInt32LE(pngBuf.length, 8)
  entry.writeUInt32LE(22, 12) // offset
  return Buffer.concat([header, entry, pngBuf])
}

function run(cmd, args) {
  return new Promise((resolve) => {
    execFile(cmd, args, { timeout: 15000, windowsHide: true }, () => resolve())
  })
}

/** 更新桌面 / 开始菜单里指向 NeoRavenLauncher 的快捷方式图标 */
async function updateShortcuts(icoPath) {
  if (process.platform !== 'win32') return { updated: 0 }
  const ps = `
$ErrorActionPreference = 'SilentlyContinue'
$ws = New-Object -ComObject WScript.Shell
$dirs = @(
  [Environment]::GetFolderPath('Desktop'),
  [Environment]::GetFolderPath('CommonDesktopDirectory'),
  [Environment]::GetFolderPath('StartMenu'),
  [Environment]::GetFolderPath('CommonStartMenu')
)
$ico = '${icoPath.replace(/'/g, "''")}'
$count = 0
foreach ($d in $dirs) {
  if (!(Test-Path $d)) { continue }
  Get-ChildItem -Path $d -Filter *.lnk -Recurse | ForEach-Object {
    $s = $ws.CreateShortcut($_.FullName)
    if ($s.TargetPath -like '*NeoRavenLauncher*') {
      $s.IconLocation = "$ico,0"
      $s.Save()
      $count++
    }
  }
}
Write-Output $count
`
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', ps],
      { timeout: 20000, windowsHide: true },
      (err, stdout) => {
        const n = parseInt(String(stdout || '').trim(), 10)
        resolve({ updated: Number.isFinite(n) ? n : 0, error: err ? err.message : null })
      }
    )
  }).then(async (r) => {
    // 刷新系统图标缓存（失败无害）
    await run('ie4uinit.exe', ['-show'])
    return r
  })
}

/**
 * 应用图标颜色：
 * 1) 窗口左上角图标立即更新
 * 2) 生成 .ico 落盘
 * 3) 重写桌面/开始菜单快捷方式的图标位置（可延后执行）
 */
async function applyIconColor({ pngDataUrl, color, userData, skipShortcuts = false, onlyShortcuts = false, silent = false }) {
  const hex = String(color || '').replace('#', '').toLowerCase() || 'custom'
  const dir = path.join(userData, 'icons')
  const icoPath = path.join(dir, `neoraven-${hex}.ico`)

  if (!onlyShortcuts) {
    const img = nativeImage.createFromDataURL(pngDataUrl)
    if (img.isEmpty()) throw new Error('图标渲染结果为空')

    for (const win of BrowserWindow.getAllWindows()) {
      if (!win.isDestroyed()) win.setIcon(img)
    }

    fs.mkdirSync(dir, { recursive: true })
    const existed = fs.existsSync(icoPath)
    fs.writeFileSync(icoPath, pngToIco(img.toPNG()))
    // 启动静默同步：若该颜色 ico 已存在，说明快捷方式此前已指向它，省去重复刷
    if (silent && existed) skipShortcuts = true

    try {
      // 同步一份到应用自身目录，便于手动指向
      const resDir = app.isPackaged ? path.dirname(process.execPath) : path.join(__dirname, '..', '..')
      fs.copyFileSync(icoPath, path.join(resDir, 'neoraven-custom.ico'))
    } catch {
      /* 只读安装目录时忽略 */
    }
  }

  if (skipShortcuts) return { icoPath, shortcuts: 0, deferred: true }
  const shorts = await updateShortcuts(icoPath)
  return { icoPath, shortcuts: shorts.updated }
}

module.exports = { applyIconColor, pngToIco }
