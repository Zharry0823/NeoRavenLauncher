const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')
const os = require('os')
const { execFile } = require('child_process')
const AdmZip = require('adm-zip')
const { ensureDir, exists, download } = require('./download')

const IS_WIN = process.platform === 'win32'
const IS_MAC = process.platform === 'darwin'
const EXE = IS_WIN ? 'java.exe' : 'java'

function probe(javaExe) {
  return new Promise((resolve) => {
    if (!javaExe || !fs.existsSync(javaExe)) return resolve(null)
    execFile(javaExe, ['-version'], { windowsHide: true, timeout: 15000 }, (err, stdout, stderr) => {
      const out = `${stdout || ''}${stderr || ''}`
      const m = out.match(/version\s+"([^"]+)"/)
      if (!m) return resolve(null)
      const version = m[1]
      const major = version.startsWith('1.') ? version.split('.')[1] : version.split('.')[0]
      resolve({ path: javaExe, version, major: Number(major) })
    })
  })
}

function globDirs(parent, prefix) {
  try {
    return fs
      .readdirSync(parent, { withFileTypes: true })
      .filter((d) => d.isDirectory() && (!prefix || d.name.toLowerCase().startsWith(prefix.toLowerCase())))
      .map((d) => path.join(parent, d.name))
  } catch {
    return []
  }
}

function candidates(settings, rootDir) {
  const list = []
  const push = (p) => p && list.push(p)

  push(settings.javaPath)
  push(path.join(rootDir, 'runtime', 'jre8', 'bin', EXE))

  if (IS_WIN) {
    for (const base of [
      'C:\\Program Files\\Java',
      'C:\\Program Files (x86)\\Java',
      'C:\\Program Files\\Eclipse Adoptium',
      'C:\\Program Files\\BellSoft',
      'C:\\Program Files\\Zulu',
      'C:\\Program Files\\Microsoft'
    ]) {
      for (const dir of globDirs(base, 'jre1.8')
        .concat(globDirs(base, 'jdk1.8'), globDirs(base, 'jre-8'), globDirs(base, 'jdk-8'))
        .concat(globDirs(base, 'zulu-8'), globDirs(base, 'liberica'), globDirs(base, 'openjdk8'), globDirs(base, 'jdk8'))) {
        push(path.join(dir, 'bin', EXE))
      }
    }
    const local = process.env.LOCALAPPDATA
    if (local) {
      for (const dir of globDirs(path.join(local, 'Programs', 'Java'), 'jre1.8')) push(path.join(dir, 'bin', EXE))
      push(path.join(local, 'Packages', 'Microsoft.4297127D64EC6_8wekyb3d8bbwe', 'LocalState', 'runtime', 'java-runtime-gamma', 'windows-x64', 'java-runtime-gamma', 'bin', EXE))
    }
    push('C:\\Program Files (x86)\\Minecraft Launcher\\runtime\\jre-x64\\bin\\java.exe')
  }

  if (IS_MAC) {
    for (const dir of globDirs('/Library/Java/JavaVirtualMachines')) {
      push(path.join(dir, 'Contents', 'Home', 'bin', 'java'))
    }
    push(path.join(os.homedir(), 'Library/Application Support/minecraft/runtime/jre-x64/jre.bundle/Contents/Home/bin/java'))
    push('/usr/bin/java')
  }

  if (!IS_WIN) push('/usr/bin/java')

  const fromPath = (process.env.PATH || '')
    .split(path.delimiter)
    .map((p) => path.join(p, EXE))
    .filter((p) => {
      try {
        return fs.existsSync(p)
      } catch {
        return false
      }
    })
  list.push(...fromPath)

  return [...new Set(list.filter(Boolean))]
}

async function detectJava(settings, rootDir) {
  for (const candidate of candidates(settings, rootDir)) {
    const info = await probe(candidate)
    if (info && info.major === 8) return { ...info, found: true, source: 'local' }
  }
  // 退回任意可用 JDK（仅用于提示）
  for (const candidate of candidates(settings, rootDir)) {
    const info = await probe(candidate)
    if (info) return { ...info, found: true, source: 'local', compatible: false }
  }
  return { found: false }
}

function adoptiumUrls() {
  const platform = process.platform
  const arch = process.arch === 'arm64' ? 'aarch64' : 'x64'
  const osName = platform === 'win32' ? 'windows' : platform === 'darwin' ? 'mac' : 'linux'
  const ext = platform === 'win32' ? 'zip' : 'tar.gz'
  // Zulu CDN 在国内速度明显快于 Adoptium（后者 307 跳 GitHub），故优先
  const urls = []
  if (platform === 'win32') {
    urls.push('https://cdn.azul.com/zulu/bin/zulu8.78.0.19-ca-jre8.0.412-win_x64.zip')
  } else if (platform === 'darwin') {
    urls.push(
      arch === 'aarch64'
        ? 'https://cdn.azul.com/zulu/bin/zulu8.78.0.19-ca-jre8.0.412-macosx_aarch64.tar.gz'
        : 'https://cdn.azul.com/zulu/bin/zulu8.78.0.19-ca-jre8.0.412-macosx_x64.tar.gz'
    )
  }
  urls.push(`https://api.adoptium.net/v3/binary/latest/8/ga/${osName}/${arch}/jre/hotspot/normal/eclipse`)
  return { urls, ext }
}

async function findJavaExe(dir) {
  const wanted = IS_WIN ? 'java.exe' : 'java'
  const stack = [dir]
  while (stack.length) {
    const cur = stack.pop()
    let entries = []
    try {
      entries = fs.readdirSync(cur, { withFileTypes: true })
    } catch {
      continue
    }
    for (const e of entries) {
      const full = path.join(cur, e.name)
      if (e.isDirectory()) {
        if (e.name === 'bin') {
          const exe = path.join(full, wanted)
          if (fs.existsSync(exe)) return exe
        }
        stack.push(full)
      }
    }
  }
  return null
}

async function ensureJava({ settings, rootDir, onProgress }) {
  const detected = await detectJava(settings, rootDir)
  if (detected.found !== false && detected.major === 8) return detected
  if (settings.autoJava === false) {
    throw new Error('未找到 Java 8 运行时，请在“高级”中手动指定 Java 路径，或开启自动下载。')
  }

  const runtimeDir = path.join(rootDir, 'runtime', 'jre8')
  const cached = await findJavaExe(runtimeDir)
  if (cached) {
    const info = await probe(cached)
    if (info && info.major === 8) return { ...info, source: 'bundled' }
  }

  onProgress && onProgress({ detail: '正在下载 Java 8 运行时（约 40 MB）…', percent: 2 })
  const { urls, ext } = adoptiumUrls()
  const archive = path.join(rootDir, 'runtime', `jre8.${ext}`)
  let lastReport = 0
  const onBytes = (bytes, total) => {
    if (!total) return
    const now = Date.now()
    if (now - lastReport < 300) return
    lastReport = now
    onProgress && onProgress({ percent: Math.min(28, 2 + (bytes / total) * 26), detail: '正在下载 Java 8 运行时…' })
  }
  let lastError = null
  for (const url of urls) {
    try {
      await download(url, archive, { retries: 2, onBytes })
      lastError = null
      break
    } catch (e) {
      lastError = e
      await fsp.rm(archive, { force: true }).catch(() => {})
    }
  }
  if (lastError) throw new Error('Java 8 运行时下载失败：' + lastError.message)

  await ensureDir(runtimeDir)
  onProgress && onProgress({ percent: 30, detail: '正在解压 Java 8 运行时…' })
  if (IS_WIN) {
    const zip = new AdmZip(archive)
    zip.extractAllTo(runtimeDir, true)
  } else {
    await new Promise((resolve, reject) => {
      execFile('tar', ['-xzf', archive, '-C', runtimeDir], { maxBuffer: 1024 * 1024 * 8 }, (err) =>
        err ? reject(err) : resolve()
      )
    })
  }
  await fsp.rm(archive, { force: true }).catch(() => {})

  const exe = await findJavaExe(runtimeDir)
  if (!exe) throw new Error('Java 运行时解压失败，未找到可执行文件')
  const info = await probe(exe)
  if (!info || info.major !== 8) throw new Error('Java 运行时版本异常，需要 Java 8')
  return { ...info, source: 'bundled' }
}

module.exports = { detectJava, ensureJava, probe, findJavaExe }
