const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')
const crypto = require('crypto')
const { spawn } = require('child_process')
const { ensureDir, sizeOf } = require('./download')
const { ensureVanilla, ruleAllows, VERSION } = require('./vanilla')
const { ensureForge, FORGE_VERSION } = require('./forge')
const { ensureJava } = require('./java')

function offlineUuid(name) {
  const hash = crypto.createHash('md5').update(`OfflinePlayer:${name}`, 'utf8').digest()
  hash[6] = (hash[6] & 0x0f) | 0x30
  hash[8] = (hash[8] & 0x3f) | 0x80
  const hex = hash.toString('hex')
  return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-')
}

function splitArgs(str) {
  if (!str) return []
  const out = []
  const re = /"([^"]*)"|(\S+)/g
  let m
  while ((m = re.exec(str))) out.push(m[1] !== undefined ? m[1] : m[2])
  return out
}

function collectClasspath(root, vanillaJson, forgeInfo, clientJar) {
  const map = new Map()
  const add = (name, rel) => {
    const [g, a] = name.split(':')
    map.set(`${g}:${a}`, path.join(root, 'libraries', rel))
  }
  for (const lib of vanillaJson.libraries) {
    if (!ruleAllows(lib.rules)) continue
    const art = lib.downloads && lib.downloads.artifact
    if (!art) continue
    add(lib.name, art.path)
  }
  const forgeId = forgeInfo.versionInfo.id
  for (const lib of forgeInfo.versionInfo.libraries || []) {
    if (lib.clientreq === false) continue
    const [coords] = lib.name.split('@')
    const parts = coords.split(':')
    const rel =
      parts[1] === 'forge' && parts.length === 3
        ? `net/minecraftforge/forge/${parts[2]}/forge-${parts[2]}-universal.jar`
        : `${parts[0].replace(/\./g, '/')}/${parts[1]}/${parts[2]}/${parts[1]}-${parts[2]}${
            parts[3] ? '-' + parts[3] : ''
          }.jar`
    add(lib.name, rel)
  }
  map.set('__client__', clientJar)
  return [...map.values()]
}

function substitute(template, vars) {
  return template.replace(/\$\{([^}]+)\}/g, (raw, key) => (vars[key] !== undefined ? vars[key] : raw))
}

async function payloadModJar() {
  const candidates = [
    path.join(process.resourcesPath || '', 'extra', 'NeoRaven.jar'),
    path.join(__dirname, '..', '..', 'build', 'extra', 'NeoRaven.jar')
  ]
  for (const c of candidates) {
    try {
      const st = await fsp.stat(c)
      if (st.isFile() && st.size > 1024) return c
    } catch {
      /* next */
    }
  }
  return null
}

async function installMod(settings, onLog) {
  // 1) 更新模块缓存的客户端 jar（rootDir/clients/<version>/）优先
  if (settings.clientVersion) {
    try {
      const dir = path.join(settings.rootDir, 'clients', String(settings.clientVersion))
      const files = await fsp.readdir(dir)
      const jar = files.find((f) => f.toLowerCase().endsWith('.jar'))
      if (jar) {
        await ensureDir(settings.modsDir)
        const dest = path.join(settings.modsDir, 'NeoRaven.jar')
        await fsp.copyFile(path.join(dir, jar), dest)
        onLog(`[launcher] 已注入客户端 ${settings.clientVersion} → ${dest}`)
        return dest
      }
    } catch {
      /* 回落到内置 jar */
    }
  }
  // 2) 内置 NeoRaven.jar
  const src = await payloadModJar()
  if (!src) {
    onLog('[launcher] 未找到客户端 jar，跳过注入（将在下次更新检查时自动下载）')
    return null
  }
  await ensureDir(settings.modsDir)
  const dest = path.join(settings.modsDir, 'NeoRaven.jar')
  const [a, b] = await Promise.all([sizeOf(src), sizeOf(dest)])
  if (a !== b) {
    await fsp.copyFile(src, dest)
    onLog(`[launcher] 已注入客户端 → ${dest}`)
  } else {
    onLog('[launcher] 客户端已是最新')
  }
  return dest
}

/**
 * 完整启动流程。返回 child_process 实例。
 */
async function launchGame(settings, handlers = {}) {
  const onLog = handlers.onLog || (() => {})
  const onState = handlers.onState || (() => {})
  const state = (phase, percent, detail) => onState({ phase, percent, detail, running: true })

  const root = settings.rootDir
  const memory = Math.min(32768, Math.max(1024, Number(settings.memoryMb) || 4096))

  state('prepare', 2, '正在准备启动环境…')
  await ensureDir(root)
  await ensureDir(settings.gameDir)
  await ensureDir(settings.modsDir)
  await ensureDir(settings.resourcePacksDir)
  await ensureDir(settings.savesDir)

  // 1. Java
  state('java', 5, '正在检查 Java 8 运行时…')
  const java = await ensureJava({
    settings,
    rootDir: root,
    onProgress: (p) => state('java', 5 + Math.min(10, (p.percent || 0) * 0.35), p.detail || '正在准备 Java…')
  })
  onLog(`[launcher] Java ${java.version} · ${java.path}`)

  // 2. 原版
  state('vanilla', 16, '正在校验 Minecraft 1.8.9 核心文件…')
  const vanilla = await ensureVanilla(root, (p) => {
    let percent = 16
    if (p.stage === 'libraries') percent = 16 + (p.done / Math.max(1, p.total)) * 14
    else if (p.stage === 'client') percent = 31
    else if (p.stage === 'natives') percent = 32 + (p.done / Math.max(1, p.total)) * 3
    else if (p.stage === 'assets') percent = 35 + (p.done / Math.max(1, p.total)) * 30
    const label =
      p.stage === 'assets'
        ? `正在同步游戏资源 ${p.done}/${p.total}`
        : p.stage === 'libraries'
          ? `正在同步依赖库 ${p.done}/${p.total}`
          : '正在准备运行环境…'
    state('vanilla', percent, label)
  })
  onLog(`[launcher] 原版 1.8.9 就绪 · ${vanilla.clientJar}`)

  // 3. Forge
  state('forge', 66, '正在部署 Forge 11.15.1.2318…')
  const forge = await ensureForge(root, (p) =>
    state('forge', 66 + (Math.min(100, p.percent || 0) / 100) * 12, p.detail || '正在部署 Forge…')
  )
  if (forge.warnings && forge.warnings.length) {
    for (const w of forge.warnings) onLog(`[launcher] 组件告警：${w}`)
  }
  onLog(`[launcher] Forge ${FORGE_VERSION} 就绪`)

  // 4. 客户端模组
  state('mods', 80, '正在注入 NeoRaven 客户端…')
  await installMod(settings, onLog)

  // 5. 组装命令行
  state('launch', 88, '正在构建启动参数…')
  const classpath = collectClasspath(root, vanilla.versionJson, forge, vanilla.clientJar)
  const sep = process.platform === 'win32' ? ';' : ':'
  const username = (settings.username || 'Steve').trim() || 'Steve'
  const vars = {
    auth_player_name: username,
    version_name: forge.forgeId,
    game_directory: settings.gameDir,
    assets_root: vanilla.assetsRoot,
    assets_index_name: vanilla.assetIndexId,
    auth_uuid: offlineUuid(username),
    auth_access_token: '0',
    user_properties: '{}',
    user_type: 'legacy',
    version_type: 'release',
    game_assets: vanilla.assetsRoot,
    auth_session: '-'
  }

  const jvmArgs = [
    `-Xmx${memory}M`,
    `-Xms${Math.min(memory, 1024)}M`,
    '-XX:+UnlockExperimentalVMOptions',
    '-XX:G1NewSizePercent=20',
    '-XX:G1ReservePercent=20',
    '-XX:MaxGCPauseMillis=50',
    '-XX:G1HeapRegionSize=16M',
    '-Djava.library.path=' + vanilla.nativesDir,
    '-Dminecraft.launcher.brand=NeoRavenLauncher',
    '-Dminecraft.launcher.version=1.0.0',
    '-Dfml.ignoreInvalidMinecraftCertificates=true',
    '-Dfml.ignorePatchDiscrepancies=true',
    ...splitArgs(settings.jvmArgs),
    '-cp',
    classpath.join(sep)
  ]

  const mcArgs = splitArgs(substitute(forge.versionInfo.minecraftArguments, vars))

  if (settings.fullscreen) mcArgs.push('--fullscreen')
  if (!settings.fullscreen) {
    mcArgs.push('--width', String(settings.width || 1280), '--height', String(settings.height || 720))
  }

  const args = [...jvmArgs, forge.versionInfo.mainClass, ...mcArgs]

  const missing = classpath.filter((p) => {
    try {
      return !fs.existsSync(p)
    } catch {
      return true
    }
  })
  if (missing.length) {
    throw new Error(
      `缺少 ${missing.length} 个必要依赖：${missing
        .slice(0, 3)
        .map((p) => path.basename(p))
        .join('、')}${missing.length > 3 ? ' 等' : ''}。请检查网络后重新启动以自动补齐。`
    )
  }

  onLog('[launcher] 启动命令已生成，正在拉起游戏进程…')
  state('launch', 94, '正在启动 Minecraft…')

  // Windows 下用 javaw.exe：无控制台子系统，窗口创建更可靠；
  // java.exe + windowsHide 有时会令 LWJGL 窗口无法显示（只剩 __wglDummyWindowFodder）
  let javaExe = java.path
  if (process.platform === 'win32' && /java\.exe$/i.test(javaExe)) {
    const javaw = path.join(path.dirname(javaExe), 'javaw.exe')
    try {
      if (fs.existsSync(javaw)) javaExe = javaw
    } catch {
      /* 保留 java.exe */
    }
  }

  const child = spawn(javaExe, args, {
    cwd: settings.gameDir,
    windowsHide: false,
    stdio: ['ignore', 'pipe', 'pipe'],
    env: { ...process.env, JAVA_HOME: path.dirname(path.dirname(java.path)) }
  })

  const startedAt = Date.now()
  child.stdout.on('data', (d) => onLog(d.toString('utf8').replace(/\r/g, '')))
  child.stderr.on('data', (d) => onLog(d.toString('utf8').replace(/\r/g, '')))
  child.on('spawn', () => {
    state('running', 100, `Minecraft 1.8.9 · NeoRaven 已启动（${username}）`)
    onLog('[launcher] 游戏进程已拉起，窗口稍候会出现在桌面（可能在其他窗口后方）')
  })
  child.on('error', (e) => {
    onState({ phase: 'error', percent: 0, detail: '启动失败：' + e.message, running: false, error: e.message })
  })
  child.on('exit', (code) => {
    const livedSec = (Date.now() - startedAt) / 1000
    onLog(`[launcher] 游戏进程已退出（code ${code}，存活 ${livedSec.toFixed(1)}s）`)
    let detail
    if (code === 0) {
      detail = '游戏已退出'
    } else if (livedSec < 12) {
      detail = `游戏启动后立即崩溃（code ${code}），请展开启动日志查看红字报错`
    } else {
      detail = `游戏异常退出（code ${code}）`
    }
    onState({
      phase: code === 0 ? 'idle' : 'error',
      percent: 0,
      detail,
      running: false,
      error: code === 0 ? null : detail
    })
  })

  return child
}

module.exports = { launchGame, offlineUuid }
