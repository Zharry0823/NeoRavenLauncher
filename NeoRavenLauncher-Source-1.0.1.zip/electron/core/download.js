const fs = require('fs')
const fsp = require('fs').promises
const path = require('path')

async function ensureDir(dir) {
  await fsp.mkdir(dir, { recursive: true })
}

async function exists(p) {
  try {
    await fsp.access(p)
    return true
  } catch {
    return false
  }
}

async function sizeOf(p) {
  try {
    return (await fsp.stat(p)).size
  } catch {
    return 0
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

/**
 * 国内镜像重写：Mojang / Forge 官方源在国内经常几 KB/s 甚至超时，
 * 统一走 BMCLAPI（bangbang93 镜像），失败再回退官方源。
 */
const MIRRORS = [
  [/^https:\/\/libraries\.minecraft\.net\//, 'https://bmclapi2.bangbang93.com/maven/'],
  [/^https:\/\/resources\.download\.minecraft\.net\//, 'https://bmclapi2.bangbang93.com/assets/'],
  [/^https:\/\/piston-meta\.mojang\.com\//, 'https://bmclapi2.bangbang93.com/'],
  [/^https:\/\/launchermeta\.mojang\.com\//, 'https://bmclapi2.bangbang93.com/'],
  [/^https:\/\/launcher\.mojang\.com\//, 'https://bmclapi2.bangbang93.com/'],
  [/^https:\/\/maven\.minecraftforge\.net\//, 'https://bmclapi2.bangbang93.com/maven/'],
  [/^https:\/\/files\.minecraftforge\.net\//, 'https://bmclapi2.bangbang93.com/maven/']
]

function mirrored(url) {
  for (const [re, base] of MIRRORS) {
    if (re.test(url)) return url.replace(re, base)
  }
  return null
}

/** 返回候选 URL 列表（镜像优先） */
function candidates(url) {
  const m = mirrored(url)
  return m && m !== url ? [m, url] : [url]
}

/**
 * 断点友好的下载：先写 .part，完成后原子重命名。
 */
async function download(url, dest, opts = {}) {
  const { retries = 3, minSize = 1, onBytes = null } = opts
  if ((await sizeOf(dest)) >= minSize) return dest
  await ensureDir(path.dirname(dest))
  const part = dest + '.part'

  const urls = candidates(url)
  let lastErr
  for (const target of urls) {
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const res = await fetch(target, {
          headers: { 'User-Agent': 'NeoRavenLauncher/1.0 (+material)' },
          redirect: 'follow',
          signal: AbortSignal.timeout(180000)
        })
        if (res.status === 404) throw Object.assign(new Error('404 Not Found: ' + target), { fatal: true })
        if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText}`)
        if (!res.body) throw new Error('空响应体')
        const total = Number(res.headers.get('content-length') || 0)
        const out = fs.createWriteStream(part)
        let written = 0
        const reader = res.body.getReader()
        try {
          for (;;) {
            const { done, value } = await reader.read()
            if (done) break
            written += value.byteLength
            if (!out.write(Buffer.from(value))) await new Promise((r) => out.once('drain', r))
            if (onBytes) onBytes(value.byteLength, total)
          }
        } finally {
          await new Promise((resolve, reject) => out.end((err) => (err ? reject(err) : resolve())))
        }
        if (total > 0 && written !== total) throw new Error(`长度不符 ${written}/${total}`)
        await fsp.rename(part, dest)
        return dest
      } catch (e) {
        lastErr = e
        await fsp.rm(part, { force: true }).catch(() => {})
        if (e.fatal) break
        await sleep(500 * (attempt + 1))
      }
    }
  }
  throw new Error(`下载失败 ${path.basename(dest)}: ${lastErr && lastErr.message}`)
}

async function getJson(url) {
  let lastErr
  for (const target of candidates(url)) {
    try {
      const res = await fetch(target, {
        headers: { 'User-Agent': 'NeoRavenLauncher/1.0' },
        redirect: 'follow',
        signal: AbortSignal.timeout(60000)
      })
      if (!res.ok) throw new Error(`HTTP ${res.status} ${target}`)
      return await res.json()
    } catch (e) {
      lastErr = e
    }
  }
  throw lastErr || new Error('获取 JSON 失败')
}

/** 并发池 */
async function runPool(items, limit, worker) {
  let cursor = 0
  const runners = Array.from({ length: Math.max(1, Math.min(limit, items.length)) }, async () => {
    for (;;) {
      const index = cursor++
      if (index >= items.length) return
      await worker(items[index], index)
    }
  })
  await Promise.all(runners)
}

/** 简易节流进度 */
function makeTicker(fn, interval = 120) {
  let last = 0
  let lastArgs = null
  return (...args) => {
    lastArgs = args
    const now = Date.now()
    if (now - last > interval) {
      last = now
      fn(...lastArgs)
    }
  }
}

module.exports = { ensureDir, exists, sizeOf, download, getJson, runPool, makeTicker, sleep }
