const path = require('path')
const fsp = require('fs').promises
const https = require('https')
const { URL } = require('url')
const { ensureDir, download } = require('./download')

const API = 'https://api.github.com/repos/Matr1ze/NeoRaven/releases'
const UA = 'NeoRavenLauncher/1.0 (+https://github.com/Matr1ze/NeoRaven)'

/* GitHub 直连在国内常被限速到几十 KB/s 或直接超时，优先走加速镜像（实测 gh-proxy 最快） */
const MIRROR_PREFIXES = [
  (u) => u.replace('https://github.com/', 'https://gh-proxy.com/https://github.com/'),
  (u) => u.replace('https://github.com/', 'https://ghproxy.net/https://github.com/'),
  (u) => u.replace('https://github.com/', 'https://mirror.ghproxy.com/https://github.com/'),
  (u) => u
]

function getJson(url, redirects = 3) {
  return new Promise((resolve, reject) => {
    const req = https.get(
      url,
      { headers: { 'User-Agent': UA, Accept: 'application/vnd.github+json' }, timeout: 20000 },
      (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects > 0) {
          res.resume()
          resolve(getJson(res.headers.location, redirects - 1)).catch(reject)
          return
        }
        if (res.statusCode !== 200) {
          res.resume()
          reject(new Error(`GitHub API HTTP ${res.statusCode}`))
          return
        }
        let buf = ''
        res.on('data', (c) => {
          buf += c
        })
        res.on('end', () => {
          try {
            resolve(JSON.parse(buf))
          } catch (e) {
            reject(e)
          }
        })
      }
    )
    req.on('timeout', () => req.destroy(new Error('timeout')))
    req.on('error', reject)
  })
}

function parseTag(t) {
  return String(t || '')
    .replace(/^v/i, '')
    .split(/[.\-+_]/)
    .map((x) => (/^\d+$/.test(x) ? Number(x) : x))
}

function cmpTag(a, b) {
  const pa = parseTag(a)
  const pb = parseTag(b)
  const n = Math.max(pa.length, pb.length)
  for (let i = 0; i < n; i++) {
    const x = pa[i] === undefined ? 0 : pa[i]
    const y = pb[i] === undefined ? 0 : pb[i]
    if (typeof x === 'number' && typeof y === 'number') {
      if (x !== y) return x - y
    } else {
      const s = String(x).localeCompare(String(y))
      if (s) return s
    }
  }
  return 0
}

/** 版本显示名：客户端名 + 版本号（绝不出现 1.8+forge 之类平台字样） */
function displayName(rel) {
  const tag = String(rel.tag_name || '').replace(/^v/i, '')
  const name = String(rel.name || '').trim()
  if (/neoraven/i.test(name)) return name.replace(/\s+/g, ' ').trim()
  return `NeoRaven ${tag}`
}

function pickJar(assets) {
  const jars = (assets || []).filter((a) => /\.jar$/i.test(a.name || ''))
  if (!jars.length) return null
  return (
    jars.find((a) => /neoraven/i.test(a.name) && !/sources|javadoc|_dev/i.test(a.name)) ||
    jars.find((a) => /^jr/i.test(a.name) && !/sources|javadoc/i.test(a.name)) ||
    jars[0]
  )
}

/**
 * 拉取 Release 列表（新→旧）。
 * 每项：{ tag, name, publishedAt, notes, jar: { name, url, size } }
 */
async function listReleases() {
  const arr = await getJson(`${API}?per_page=20`)
  const list = Array.isArray(arr) ? arr : []
  return list
    .filter((r) => !r.draft)
    .map((r) => {
      const assets = (r.assets || []).map((a) => ({ name: a.name, url: a.browser_download_url, size: a.size }))
      const jar = pickJar(assets)
      if (!jar) return null
      return {
        tag: String(r.tag_name || '').replace(/^v/i, ''),
        name: displayName(r),
        publishedAt: r.published_at || '',
        notes: String(r.body || '').slice(0, 400),
        jar
      }
    })
    .filter(Boolean)
}

function clientsDir(settings) {
  return path.join(settings.rootDir, 'clients')
}

function localJarPath(settings, tag, jarName) {
  return path.join(clientsDir(settings), tag, jarName || 'NeoRaven.jar')
}

async function hasLocalJar(settings, release) {
  try {
    const st = await fsp.stat(localJarPath(settings, release.tag, release.jar && release.jar.name))
    return st.isFile() && st.size > 1024
  } catch {
    return false
  }
}

/** 下载指定版本的客户端 jar 到本地缓存（rootDir/clients/<tag>/） */
async function ensureClientJar(settings, release, handlers = {}) {
  const onLog = handlers.onLog || (() => {})
  const onProgress = handlers.onProgress || (() => {})
  const dest = localJarPath(settings, release.tag, release.jar.name)
  await ensureDir(path.dirname(dest))
  if (await hasLocalJar(settings, release)) {
    onLog(`[update] ${release.name} 本地已有缓存`)
    return dest
  }
  let lastErr = null
  for (const mk of MIRROR_PREFIXES) {
    const url = mk(release.jar.url)
    try {
      onLog(`[update] 正在下载 ${release.name}（${release.jar.name}）…`)
      await download(url, dest, {
        retries: 2,
        onBytes: (bytes, total) => {
          if (!total) return
          onProgress({ percent: Math.min(99, (bytes / total) * 100), detail: `下载 ${release.name}…` })
        }
      })
      onLog(`[update] 下载完成 → ${dest}`)
      return dest
    } catch (e) {
      lastErr = e
      onLog(`[update] 镜像失败 ${new URL(url).host}: ${e.message}`)
    }
  }
  throw lastErr || new Error('下载失败')
}

/** 把客户端 jar 安装进 mods 目录（清理旧版 NeoRaven jar，避免重复加载） */
async function applyToMods(settings, jarPath, onLog = () => {}) {
  const modsDir = settings.modsDir
  await ensureDir(modsDir)
  const dest = path.join(modsDir, 'NeoRaven.jar')
  try {
    const files = await fsp.readdir(modsDir)
    for (const f of files) {
      if (!f.toLowerCase().endsWith('.jar')) continue
      if (/^neoraven/i.test(f) && path.join(modsDir, f) !== dest) {
        await fsp.unlink(path.join(modsDir, f)).catch(() => {})
      }
    }
  } catch {
    /* 忽略 */
  }
  await fsp.copyFile(jarPath, dest)
  onLog(`[update] 已应用客户端 → ${dest}`)
  return dest
}

/**
 * 启动时检测更新：有更新（或本地未装）就自动下载并应用。
 * 返回 { releases, current, latest, updated, error }
 */
async function checkAndApply(store, handlers = {}) {
  const onLog = handlers.onLog || (() => {})
  const settings = store.get()
  const autoUpdate = settings.autoUpdate !== false
  try {
    const releases = await listReleases()
    if (!releases.length) {
      return { releases: [], current: settings.clientVersion || '', latest: null, updated: false, error: '没有可用的版本' }
    }
    const latest = releases[0]
    const currentTag = settings.clientVersion || ''
    const needUpdate = !currentTag || cmpTag(latest.tag, currentTag) > 0

    if (needUpdate && autoUpdate) {
      onLog(`[update] 发现新版本 ${latest.name}，自动下载并应用…`)
      const jarPath = await ensureClientJar(settings, latest, handlers)
      await applyToMods(settings, jarPath, onLog)
      await store.save({ clientVersion: latest.tag })
      return { releases, current: latest.tag, latest: latest.tag, updated: true }
    }

    // 当前选择的版本若本地缓存缺失，补下载（不切换版本）
    const current = releases.find((r) => r.tag === currentTag) || latest
    if (!(await hasLocalJar(settings, current))) {
      const jarPath = await ensureClientJar(settings, current, handlers)
      await applyToMods(settings, jarPath, onLog)
    }
    return { releases, current: current.tag, latest: latest.tag, updated: false }
  } catch (e) {
    return {
      releases: [],
      current: settings.clientVersion || '',
      latest: null,
      updated: false,
      error: e && e.message ? e.message : String(e)
    }
  }
}

/** 用户在列表里手动选择某个版本：下载（若缺）并应用 */
async function selectVersion(store, tag, handlers = {}) {
  const onLog = handlers.onLog || (() => {})
  const settings = store.get()
  const releases = await listReleases()
  const rel = releases.find((r) => r.tag === tag)
  if (!rel) throw new Error(`未找到版本 ${tag}`)
  const jarPath = await ensureClientJar(settings, rel, handlers)
  await applyToMods(settings, jarPath, onLog)
  await store.save({ clientVersion: rel.tag })
  return { tag: rel.tag, name: rel.name }
}

module.exports = {
  listReleases,
  checkAndApply,
  selectVersion,
  ensureClientJar,
  applyToMods,
  hasLocalJar,
  localJarPath,
  cmpTag
}
