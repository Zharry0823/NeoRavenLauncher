const { contextBridge, ipcRenderer } = require('electron')

contextBridge.exposeInMainWorld('neoraven', {
  platform: process.platform,
  getBootstrap: () => ipcRenderer.invoke('app:bootstrap'),
  saveSettings: (patch) => ipcRenderer.invoke('settings:save', patch),
  setupUser: (username) => ipcRenderer.invoke('user:setup', username),
  renameUser: (username) => ipcRenderer.invoke('user:rename', username),
  checkUpdates: () => ipcRenderer.invoke('updates:check'),
  selectVersion: (tag) => ipcRenderer.invoke('versions:select', tag),
  applyIconColor: (pngDataUrl, color, opts) => ipcRenderer.invoke('icon:apply', { pngDataUrl, color, ...(opts || {}) }),
  pickFolder: (opts) => ipcRenderer.invoke('dialog:folder', opts),
  pickJava: () => ipcRenderer.invoke('dialog:javafile'),
  detectJava: (p) => ipcRenderer.invoke('java:detect', p),
  openPath: (target) => ipcRenderer.invoke('shell:open', target),
  scanMods: () => ipcRenderer.invoke('mods:scan'),
  launch: () => ipcRenderer.invoke('launch:start'),
  cancel: () => ipcRenderer.invoke('launch:cancel'),
  minimize: () => ipcRenderer.invoke('win:minimize'),
  maximize: () => ipcRenderer.invoke('win:maximize'),
  close: () => ipcRenderer.invoke('win:close'),
  onState: (cb) => {
    const h = (_e, payload) => cb(payload)
    ipcRenderer.on('launch:state', h)
    return () => ipcRenderer.removeListener('launch:state', h)
  },
  onLog: (cb) => {
    const h = (_e, payload) => cb(payload)
    ipcRenderer.on('launch:log', h)
    return () => ipcRenderer.removeListener('launch:log', h)
  },
  onSettings: (cb) => {
    const h = (_e, payload) => cb(payload)
    ipcRenderer.on('settings:changed', h)
    return () => ipcRenderer.removeListener('settings:changed', h)
  },
  onUpdates: (cb) => {
    const h = (_e, payload) => cb(payload)
    ipcRenderer.on('updates:state', h)
    return () => ipcRenderer.removeListener('updates:state', h)
  },
  onIdentified: (cb) => {
    const h = (_e, payload) => cb(payload)
    ipcRenderer.on('user:identified', h)
    return () => ipcRenderer.removeListener('user:identified', h)
  }
})
