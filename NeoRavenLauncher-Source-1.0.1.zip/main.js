const { app, BrowserWindow, ipcMain, dialog, shell, nativeTheme } = require('electron')
const path = require('path')
const fs = require('fs')
const fsp = require('fs').promises
const os = require('os')

const { SettingsStore } = require('./core/settings')
const { detectJava } = require('./core/java')
const { launchGame } = require('./core/launch')

const isMac = process.platform === 'darwin'
const isWin = process.platform === 'win32'
const osBuild = Number((os.release().split('.')[2] || 0))
const SUPPORTS_ACRYLIC = isWin && osBuild >= 22000

let win = null
let store = null
let gameChild = null
let lastJavaInfo = null

/* 启动阶段日志：设置 NRL_BOOTLOG=1 时写入 userData/boot.log，便于排查打包环境问题 */
function bootLog(message) {
  // 打包诊断：无条件写启动日志
  try {
    fs.appendFileSync(path.join(app.getPath('userData'), 'boot.log'), `${new Date().toISOString()} ${message}\n`)
  } catch {
    /* 忽略 */
  }
}

process.on('uncaughtException', (e) => bootLog('uncaughtException ' + (e && e.stack)))
process.on('unhandledRejection', (e) => bootLog('unhandledRejection ' + (e && e.stack)))
bootLog('main loaded, pid=' + process.pid + ' packaged=' + require('electron').app.isPackaged)
app.setName('NeoRavenLauncher')
if (process.platform === 'win32') app.setAppUserModelId('com.neoraven.launcher')

const gotLock = app.requestSingleInstanceLock()
bootLog('single-instance lock: ' + gotLock)
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    if (win) {
      if (win.isMinimized()) win.restore()
      win.focus()
    }
  })
}

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload)
}

function createWindow() {
  const settings = store.get()
  nativeTheme.themeSource = 'dark'

  win = new BrowserWindow({
    width: 1200,
    height: 800,
    minWidth: 1010,
    minHeight: 680,
    show: false,
    frame: false,
    roundedCorners: true,
    transparent: SUPPORTS_ACRYLIC || isMac,
    backgroundColor: SUPPORTS_ACRYLIC || isMac ? '#00000000' : '#121014',
    backgroundMaterial: SUPPORTS_ACRYLIC ? 'acrylic' : undefined,
    titleBarStyle: isMac ? 'hiddenInset' : undefined,
    trafficLightPosition: isMac ? { x: 18, y: 22 } : undefined,
    vibrancy: isMac ? 'under-window' : undefined,
    visualEffectState: isMac ? 'active' : undefined,
    title: 'NeoRavenLauncher',
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
      backgroundThrottling: false
    }
  })

  win.once('ready-to-show', () => {
    bootLog('ready-to-show')
    win.show()
    win.focus()
    if (process.env.NRL_TOPMOST) win.setAlwaysOnTop(true, 'screen-saver')
  })

  win.webContents.on('did-fail-load', (_e, code, desc, url) => {
    bootLog(`did-fail-load ${code} ${desc} ${url}`)
    win.show()
  })
  win.webContents.on('render-process-gone', (_e, details) => {
    bootLog(`render-process-gone ${JSON.stringify(details)}`)
  })
  win.webContents.on('console-message', (_e, level, message, line, source) => {
    bootLog(`console(${level}) ${message} @${source}:${line}`)
  })
  // 兜底：即便渲染进程报错也让窗口可见，避免“无窗口”状态
  setTimeout(() => {
    if (win && !win.isDestroyed() && !win.isVisible()) {
      bootLog('fallback-show')
      win.show()
    }
  }, 3500)

  const devUrl = process.env.VITE_DEV_SERVER_URL
  const initialPage = process.env.NRL_PAGE ? `?page=${process.env.NRL_PAGE}` : ''
  if (devUrl) {
    win.loadURL(devUrl + initialPage).catch((e) => bootLog('loadURL failed ' + e.message))
  } else {
    const index = path.join(__dirname, '..', 'dist-renderer', 'index.html')
    bootLog('loading ' + index)
    win.loadFile(index, initialPage ? { search: initialPage.slice(1) } : undefined).catch((e) => {
      bootLog('loadFile failed ' + e.message)
      win.show()
    })
  }

  win.on('closed', () => {
    win = null
  })

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url)
    return { action: 'deny' }
  })
}

async function bootstrap() {
  const settings = store.get()
  if (!lastJavaInfo) {
    try {
      lastJavaInfo = await detectJava(settings, settings.rootDir)
    } catch {
      lastJavaInfo = { found: false }
    }
  }
  return {
    settings,
    app: {
      version: app.getVersion(),
      electron: process.versions.electron,
      chrome: process.versions.chrome,
      node: process.versions.node,
      platform: process.platform,
      arch: process.arch,
      osBuild,
      acrylic: SUPPORTS_ACRYLIC,
      isMac,
      pathSep: path.sep
    },
    java: lastJavaInfo
  }
}

function registerIpc() {
  ipcMain.handle('app:bootstrap', async () => bootstrap())

  ipcMain.handle('settings:save', async (_e, patch) => {
    const next = await store.save(patch || {})
    send('settings:changed', next)
    return next
  })

  ipcMain.handle('dialog:folder', async (_e, { title, current } = {}) => {
    const res = await dialog.showOpenDialog(win, {
      title: title || '选择文件夹',
      defaultPath: current && fs.existsSync(current) ? current : undefined,
      properties: ['openDirectory', 'createDirectory']
    })
    if (res.canceled || !res.filePaths.length) return null
    return res.filePaths[0]
  })

  ipcMain.handle('dialog:javafile', async () => {
    const res = await dialog.showOpenDialog(win, {
      title: '选择 java 可执行文件',
      properties: ['openFile'],
      filters:
        process.platform === 'win32'
          ? [{ name: 'Java', extensions: ['exe'] }]
          : [{ name: 'All files', extensions: ['*'] }]
    })
    if (res.canceled || !res.filePaths.length) return null
    return res.filePaths[0]
  })

  ipcMain.handle('java:detect', async (_e, customPath) => {
    const settings = { ...store.get(), javaPath: customPath || '' }
    const info = await detectJava(settings, settings.rootDir)
    if (info && info.path) lastJavaInfo = info
    return info
  })

  ipcMain.handle('shell:open', async (_e, target) => {
    if (!target) return { ok: false }
    try {
      await fsp.mkdir(target, { recursive: true })
    } catch {
      /* 忽略 */
    }
    const err = await shell.openPath(target)
    return { ok: !err, error: err || null }
  })

  ipcMain.handle('mods:scan', async () => {
    const dir = store.get().modsDir
    try {
      const files = await fsp.readdir(dir, { withFileTypes: true })
      const items = []
      for (const f of files) {
        if (!f.isFile() || !f.name.toLowerCase().endsWith('.jar')) continue
        const st = await fsp.stat(path.join(dir, f.name))
        items.push({ name: f.name, size: st.size, mtime: st.mtimeMs })
      }
      items.sort((a, b) => b.mtime - a.mtime)
      return { dir, count: items.length, items }
    } catch {
      return { dir, count: 0, items: [] }
    }
  })

  ipcMain.handle('launch:start', async () => {
    if (gameChild) return { ok: false, error: '游戏已在运行中' }
    const settings = store.get()
    if (!settings.username || !settings.username.trim()) {
      return { ok: false, error: '请先填写游戏用户名' }
    }
    try {
      send('launch:log', `\n[launcher] === NeoRavenLauncher ${app.getVersion()} ===\n`)
      const child = await launchGame(settings, {
        onLog: (line) => send('launch:log', line),
        onState: (s) => send('launch:state', s)
      })
      gameChild = child
      child.on('exit', () => {
        gameChild = null
      })
      await store.save({ lastLaunch: new Date().toISOString() })
      if (settings.closeOnLaunch) win && win.minimize()
      return { ok: true }
    } catch (e) {
      const message = e && e.message ? e.message : String(e)
      send('launch:state', { phase: 'error', percent: 0, detail: message, running: false, error: message })
      send('launch:log', `[launcher] 错误: ${message}\n`)
      gameChild = null
      return { ok: false, error: message }
    }
  })

  ipcMain.handle('launch:cancel', async () => {
    if (gameChild) {
      try {
        gameChild.kill()
      } catch {
        /* 忽略 */
      }
      gameChild = null
      send('launch:state', { phase: 'idle', percent: 0, detail: '已取消启动', running: false })
      return { ok: true }
    }
    return { ok: false }
  })

  ipcMain.handle('win:minimize', () => win && win.minimize())
  ipcMain.handle('win:maximize', () => {
    if (!win) return false
    if (win.isMaximized()) win.unmaximize()
    else win.maximize()
    return win.isMaximized()
  })
  ipcMain.handle('win:close', () => win && win.close())
}

app.whenReady().then(async () => {
  bootLog('app ready')
  store = new SettingsStore(app.getPath('userData'))
  await store.load()
  bootLog('settings loaded from ' + store.file)
  registerIpc()
  bootLog('ipc registered')
  try {
    createWindow()
    bootLog('window created')
  } catch (e) {
    bootLog('createWindow threw ' + (e && e.stack))
    throw e
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (!isMac) app.quit()
})

app.on('before-quit', () => {
  if (gameChild) {
    try {
      gameChild.kill()
    } catch {
      /* 忽略 */
    }
  }
})
