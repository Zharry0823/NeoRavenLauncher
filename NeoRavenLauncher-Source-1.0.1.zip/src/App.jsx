import React, { useEffect, useState, useCallback } from 'react'
import { ThemeProvider, CssBaseline } from '@mui/material'
import { buildTheme } from './theme'
import api from './api'
import { renderIconPng } from './components/iconRender'
import TitleBar from './components/TitleBar'
import HomePage from './pages/HomePage'
import SettingsPage from './pages/SettingsPage'

const PAGES = {
  home: { label: '启动', icon: 'play' },
  settings: { label: '设置', icon: 'gear' }
}

function RailIcon({ name }) {
  if (name === 'play') {
    return (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
        <path d="M8 5.5v13l11-6.5-11-6.5z" fill="currentColor" />
      </svg>
    )
  }
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
      <path
        d="M12 15.5A3.5 3.5 0 1 0 12 8.5a3.5 3.5 0 0 0 0 7zm7.4-2.6c.05-.3.07-.6.07-.9s-.02-.6-.07-.9l2-1.5a.5.5 0 0 0 .12-.64l-1.9-3.28a.5.5 0 0 0-.6-.22l-2.36.94a7.3 7.3 0 0 0-1.56-.9l-.36-2.5a.5.5 0 0 0-.5-.42h-3.8a.5.5 0 0 0-.5.42l-.36 2.5c-.56.23-1.08.54-1.56.9l-2.36-.94a.5.5 0 0 0-.6.22L2.48 9.86a.5.5 0 0 0 .12.64l2 1.5c-.05.3-.07.6-.07.9s.02.6.07.9l-2 1.5a.5.5 0 0 0-.12.64l1.9 3.28c.13.22.4.3.6.22l2.36-.94c.48.36 1 .67 1.56.9l.36 2.5c.04.24.25.42.5.42h3.8c.25 0 .46-.18.5-.42l.36-2.5c.56-.23 1.08-.54 1.56-.9l2.36.94c.22.08.47 0 .6-.22l1.9-3.28a.5.5 0 0 0-.12-.64l-2-1.5z"
        fill="currentColor"
      />
    </svg>
  )
}

/* 首次启动：自定义用户名（与机器码绑定，可云端找回） */
function FirstRunDialog({ onDone }) {
  const [name, setName] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async () => {
    const n = name.trim()
    if (!n || busy) return
    setBusy(true)
    await api.setupUser(n)
    setBusy(false)
    onDone(n)
  }
  return (
    <div className="modal-mask" style={{ zIndex: 200 }}>
      <div className="modal" style={{ width: 'min(360px, 90%)' }}>
        <h3>欢迎使用 NeoRaven</h3>
        <p className="first-run-hint">
          取一个用户名吧。它会与本机机器码绑定，重装或换机后可自动找回。
        </p>
        <input
          className="text-input"
          style={{ width: '100%', marginTop: 6 }}
          placeholder="输入用户名，例如 Steve"
          value={name}
          maxLength={16}
          autoFocus
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
        />
        <div className="actions">
          <button className="btn-primary-sm" onClick={submit} disabled={!name.trim() || busy}>
            {busy ? '保存中…' : '开始使用'}
          </button>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  const [settings, setSettings] = useState(null)
  const [meta, setMeta] = useState({ version: '1.0.0', platform: 'win32', material: 'blur' })
  const [java, setJava] = useState({ found: false })
  const [firstRun, setFirstRun] = useState(false)
  const [hwidMasked, setHwidMasked] = useState('')
  const [updateState, setUpdateState] = useState({ releases: [], current: '', latest: '', checking: true })
  const [page, setPage] = useState(() => {
    const q = new URLSearchParams(window.location.search).get('page')
    return q && ['home', 'settings'].includes(q) ? q : 'home'
  })
  const [railOpen, setRailOpen] = useState(false)
  const [accent, setAccent] = useState('#FF9BB2')
  const [iconColor, setIconColor] = useState('#FF9BB2')

  useEffect(() => {
    let alive = true
    api.getBootstrap().then((b) => {
      if (!alive) return
      setSettings(b.settings)
      setMeta(b.app || {})
      setJava(b.java || { found: false })
      setFirstRun(!!b.firstRun)
      setHwidMasked(b.hwidMasked || '')
      setUpdateState(b.updateState || { releases: [], current: '', latest: '', checking: true })
      const a = (b.settings && b.settings.accent) || '#FF9BB2'
      setAccent(a)
      document.documentElement.style.setProperty('--accent', a)
      // 主题色与图标色统一：图标恒跟随主题色
      setIconColor(a)
      // 启动静默同步一次图标（主题色可能来自旧配置或外部修改，保证图标与之一致）
      try {
        const png = renderIconPng(a, 256)
        api.applyIconColor(png, a, { silent: true })
      } catch {
        /* 忽略 */
      }
      // 系统材质模式（亚克力 / 振动 / CSS 兜底）
      const m = (b.app && b.app.material) || 'blur'
      document.documentElement.dataset.material = m
    })
    const offS = api.onSettings((s) => {
      setSettings(s)
      if (s && s.accent) {
        setAccent(s.accent)
        setIconColor(s.accent)
        document.documentElement.style.setProperty('--accent', s.accent)
      }
      if (s && s.userNamed) setFirstRun(false)
    })
    const offU = api.onUpdates((u) => setUpdateState(u))
    const offId = api.onIdentified(() => setFirstRun(false))
    return () => {
      alive = false
      offS && offS()
      offU && offU()
      offId && offId()
    }
  }, [])

  const save = useCallback(async (patch) => {
    const next = await api.saveSettings(patch)
    setSettings(next)
    return next
  }, [])

  const theme = React.useMemo(() => buildTheme(accent), [accent])

  if (!settings) {
    return (
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <div className="shell" />
      </ThemeProvider>
    )
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <div className="shell">
        <TitleBar iconColor={iconColor} />

        <nav className={`side-rail${railOpen ? ' expanded' : ''}`} onMouseLeave={() => setRailOpen(false)}>
          <button className="rail-toggle" onClick={() => setRailOpen((v) => !v)} title="菜单">
            <span className="rail-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </span>
            <span className="rail-label" style={{ fontSize: 12, fontWeight: 700, letterSpacing: 0.6 }}>
              NeoRaven
            </span>
          </button>

          {Object.entries(PAGES).map(([key, item]) => (
            <button
              key={key}
              className={`rail-item${page === key ? ' active' : ''}`}
              onClick={() => {
                setPage(key)
                setRailOpen(false)
              }}
              title={item.label}
            >
              <span className="rail-icon">
                <RailIcon name={item.icon} />
              </span>
              <span className="rail-label">{item.label}</span>
            </button>
          ))}
        </nav>

        <main className="content">
          {page === 'home' ? (
            <HomePage
              settings={settings}
              save={save}
              meta={meta}
              java={java}
              updateState={updateState}
              hwidMasked={hwidMasked}
            />
          ) : (
            <SettingsPage
              settings={settings}
              save={save}
              meta={meta}
              java={java}
              setJava={setJava}
              iconColor={iconColor}
              setIconColor={setIconColor}
              hwidMasked={hwidMasked}
              updateState={updateState}
            />
          )}
        </main>

        {firstRun && <FirstRunDialog onDone={() => setFirstRun(false)} />}
      </div>
    </ThemeProvider>
  )
}
