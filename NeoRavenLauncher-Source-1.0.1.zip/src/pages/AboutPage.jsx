import React from 'react'
import { Box, Button, Divider, Stack, Typography, alpha } from '@mui/material'
import GitHubIcon from '@mui/icons-material/GitHub'
import ForumRoundedIcon from '@mui/icons-material/ForumRounded'
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded'
import Logo from '../components/Logo'
import { GlassCard, PageHeader, SectionLabel, Pill } from '../components/ui'
import api from '../api'

const TECH = ['Electron', 'React 18', 'MUI 6', 'Vite', 'Framer Motion', 'NSIS']

export default function AboutPage({ app, settings }) {
  const accent = settings.accent

  return (
    <Box sx={{ pb: 2 }}>
      <PageHeader title="关于" subtitle="NeoRavenLauncher · 为 NeoRaven 客户端打造的启动器" />

      <Box sx={{ display: 'flex', gap: 2.5, alignItems: 'flex-start' }}>
        <GlassCard sx={{ flex: 1, p: 3.4 }} glow={accent}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 2.2 }}>
            <Logo size={62} accent={accent} radius={0.28} glow />
            <Box>
              <Typography variant="h2" sx={{ fontSize: 26, letterSpacing: '-.02em' }}>
                NeoRavenLauncher
              </Typography>
              <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
                <Pill color={accent}>v{app.version}</Pill>
                <Pill>Material Design 3</Pill>
                <Pill>{app.platform === 'darwin' ? 'macOS' : 'Windows'}</Pill>
              </Stack>
            </Box>
          </Box>

          <Typography sx={{ fontSize: 12.5, color: 'rgba(255,255,255,.45)', mt: 2.6, lineHeight: 1.9, maxWidth: 520 }}>
            深色亚克力界面 · 原生 Material 色板 · 一键完成 1.8.9 原版、Forge 与 NeoRaven 客户端部署。
            所有数据保存在本地，跨 Windows / macOS 使用同一套配置结构。
          </Typography>

          <Divider sx={{ my: 2.6, borderColor: 'rgba(255,255,255,.07)' }} />

          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0,1fr))', gap: 1.6 }}>
            {[
              ['构建版本', `B${app.version}`],
              ['Electron', app.electron],
              ['Chromium', app.chrome],
              ['Node.js', app.node],
              ['系统架构', app.arch],
              ['亚克力支持', app.acrylic ? 'Windows 11 DWM' : app.isMac ? 'NSVisualEffect' : 'CSS 降级']
            ].map(([k, v]) => (
              <Box
                key={k}
                sx={{
                  p: 1.4,
                  borderRadius: '12px',
                  border: '1px solid rgba(255,255,255,.06)',
                  background: 'rgba(255,255,255,.028)'
                }}
              >
                <Typography sx={{ fontSize: 10.5, color: 'rgba(255,255,255,.32)', letterSpacing: '.04em' }}>{k}</Typography>
                <Typography className="mono" sx={{ fontSize: 11.5, mt: 0.4, color: 'rgba(255,255,255,.82)' }}>
                  {v}
                </Typography>
              </Box>
            ))}
          </Box>

          <Stack direction="row" spacing={1.2} sx={{ mt: 2.8 }}>
            <Button
              size="small"
              variant="contained"
              startIcon={<DescriptionRoundedIcon sx={{ fontSize: 15 }} />}
              onClick={() => api.openPath(settings.rootDir)}
            >
              打开数据目录
            </Button>
            <Button
              size="small"
              variant="outlined"
              startIcon={<ForumRoundedIcon sx={{ fontSize: 15 }} />}
              sx={{ borderColor: alpha(accent, 0.28), color: accent }}
              onClick={() => api.openPath(settings.gameDir)}
            >
              游戏目录
            </Button>
          </Stack>
        </GlassCard>

        <Box sx={{ width: 320, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 2 }}>
          <GlassCard sx={{ p: 2.6 }}>
            <SectionLabel>技术栈</SectionLabel>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.9, mt: 1.8 }}>
              {TECH.map((t) => (
                <Box
                  key={t}
                  sx={{
                    px: 1.1,
                    height: 24,
                    display: 'grid',
                    placeItems: 'center',
                    borderRadius: '8px',
                    fontSize: 10.5,
                    fontWeight: 600,
                    color: 'rgba(255,255,255,.6)',
                    border: '1px solid rgba(255,255,255,.09)',
                    background: 'rgba(255,255,255,.03)'
                  }}
                >
                  {t}
                </Box>
              ))}
            </Box>

            <Divider sx={{ my: 2, borderColor: 'rgba(255,255,255,.06)' }} />

            <SectionLabel>致谢</SectionLabel>
            <Typography sx={{ fontSize: 11, color: 'rgba(255,255,255,.4)', mt: 1.2, lineHeight: 1.9 }}>
              OpenB4 · OpenOnyx · OpenExpo · OpenSlinky
              <br />
              以及 Minecraft、Forge、Mixin 社区。
            </Typography>
          </GlassCard>

          <GlassCard sx={{ p: 2.6 }}>
            <SectionLabel>免责声明</SectionLabel>
            <Typography sx={{ fontSize: 10.8, color: 'rgba(255,255,255,.36)', mt: 1.4, lineHeight: 1.85 }}>
              本启动器仅用于学习与研究，与 Mojang、Microsoft、Hypixel 无任何关联。请遵守目标服务器规则，
              使用风险自负。
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.8, mt: 1.8 }}>
              <GitHubIcon sx={{ fontSize: 14, color: 'rgba(255,255,255,.3)' }} />
              <Typography className="mono" sx={{ fontSize: 10.5, color: 'rgba(255,255,255,.3)' }}>
                Copyright © 2026 NeoRaven
              </Typography>
            </Box>
          </GlassCard>
        </Box>
      </Box>
    </Box>
  )
}
