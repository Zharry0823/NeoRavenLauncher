import React, { useState } from 'react'
import { Box, Button, Slider, Switch, Typography, Tooltip, alpha, Chip } from '@mui/material'
import CheckRoundedIcon from '@mui/icons-material/CheckRounded'
import ColorizeRoundedIcon from '@mui/icons-material/ColorizeRounded'
import RestartAltRoundedIcon from '@mui/icons-material/RestartAltRounded'
import { motion } from 'framer-motion'
import { ACCENTS, DEFAULT_ACCENT } from '../theme'
import { GlassCard, PageHeader, Row, SectionLabel, Pill } from '../components/ui'

function Swatch({ item, active, onClick }) {
  return (
    <Tooltip title={item.label} arrow placement="top">
      <Box
        onClick={onClick}
        sx={{
          width: 40,
          height: 40,
          borderRadius: '50%',
          display: 'grid',
          placeItems: 'center',
          cursor: 'pointer',
          position: 'relative',
          border: '1px solid rgba(255,255,255,.1)',
          background: item.color,
          boxShadow: active ? `0 0 0 2px rgba(15,14,18,.9), 0 0 0 4px ${item.color}` : 'none',
          transition: 'transform .18s cubic-bezier(.2,.8,.2,1), box-shadow .2s ease',
          '&:hover': { transform: 'scale(1.09)' }
        }}
      >
        {active && (
          <motion.div initial={{ scale: 0.4, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
            <CheckRoundedIcon sx={{ fontSize: 19, color: 'rgba(20,16,22,.82)' }} />
          </motion.div>
        )}
        {item.isDefault && !active && (
          <Box
            sx={{
              position: 'absolute',
              bottom: -1,
              right: -1,
              width: 12,
              height: 12,
              borderRadius: '50%',
              background: 'rgba(15,14,18,.9)',
              border: `1px solid ${item.color}`,
              display: 'grid',
              placeItems: 'center',
              fontSize: 7,
              color: item.color,
              fontWeight: 800
            }}
          >
            ★
          </Box>
        )}
      </Box>
    </Tooltip>
  )
}

export default function AppearancePage({ settings, update }) {
  const accent = settings.accent
  const [custom, setCustom] = useState(/^#[0-9a-fA-F]{6}$/.test(accent) ? accent : DEFAULT_ACCENT)
  const activeLabel = ACCENTS.find((a) => a.color.toLowerCase() === String(accent).toLowerCase())

  return (
    <Box sx={{ pb: 2 }}>
      <PageHeader
        title="外观主题"
        subtitle="Material Design 原生色板 · 深色亚克力界面实时生效"
        action={
          <Button
            size="small"
            startIcon={<RestartAltRoundedIcon sx={{ fontSize: 15 }} />}
            onClick={() => update({ accent: DEFAULT_ACCENT, acrylic: 0.62, animations: true, density: 1 })}
            sx={{ color: 'rgba(255,255,255,.55)' }}
          >
            恢复默认外观
          </Button>
        }
      />

      <Box sx={{ display: 'flex', gap: 2.5, alignItems: 'flex-start' }}>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <GlassCard sx={{ p: 2.8, mb: 2.5 }} glow={accent}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.6 }}>
              <SectionLabel>主题颜色</SectionLabel>
              <Box sx={{ flex: 1 }} />
              <Pill color={accent}>{activeLabel ? activeLabel.label : '自定义'}</Pill>
              <Typography className="mono" sx={{ fontSize: 11, color: 'rgba(255,255,255,.45)' }}>
                {String(accent).toUpperCase()}
              </Typography>
            </Box>
            <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.36)', mb: 2.4, lineHeight: 1.7 }}>
              以下色板取自 Material UI 官方 palette，点击即时应用；主色会同步到按钮、滑块、进度与高亮。
            </Typography>

            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1.55 }}>
              {ACCENTS.map((item) => (
                <Swatch
                  key={item.id}
                  item={item}
                  active={String(accent).toLowerCase() === item.color.toLowerCase()}
                  onClick={() => update({ accent: item.color })}
                />
              ))}

              <Tooltip title="自定义颜色" arrow>
                <Box
                  sx={{
                    width: 40,
                    height: 40,
                    borderRadius: '50%',
                    border: '1px dashed rgba(255,255,255,.24)',
                    display: 'grid',
                    placeItems: 'center',
                    position: 'relative',
                    overflow: 'hidden',
                    cursor: 'pointer',
                    '&:hover': { borderColor: alpha(accent, 0.7) }
                  }}
                >
                  <ColorizeRoundedIcon sx={{ fontSize: 16, color: 'rgba(255,255,255,.55)' }} />
                  <input
                    type="color"
                    value={custom}
                    onChange={(e) => {
                      setCustom(e.target.value.toUpperCase())
                      update({ accent: e.target.value.toUpperCase() })
                    }}
                    style={{ position: 'absolute', inset: 0, opacity: 0 }}
                  />
                </Box>
              </Tooltip>
            </Box>
          </GlassCard>

          <GlassCard sx={{ p: 2.8 }}>
            <SectionLabel sx={{ mb: 1 }}>质感与动效</SectionLabel>

            <Row label="亚克力浓度" hint="控制深色玻璃层的通透度，数值越高越不透明，性能开销更低。">
              <Typography className="mono" sx={{ fontSize: 11.5, color: alpha(accent, 0.9), width: 42, textAlign: 'right' }}>
                {Math.round((settings.acrylic ?? 0.62) * 100)}%
              </Typography>
              <Box sx={{ width: 168 }}>
                <Slider
                  min={0.2}
                  max={1}
                  step={0.02}
                  value={settings.acrylic ?? 0.62}
                  onChange={(_e, v) => update({ acrylic: v })}
                />
              </Box>
            </Row>

            <Row label="界面密度" hint="调整内容间距的紧凑程度，适合小屏或高分屏。">
              <Box sx={{ width: 168, display: 'flex', alignItems: 'center', pr: 0.5 }}>
                <Slider
                  min={0.9}
                  max={1.15}
                  step={0.05}
                  value={settings.density ?? 1}
                  valueLabelDisplay="auto"
                  onChange={(_e, v) => update({ density: v })}
                />
              </Box>
            </Row>

            <Row label="Material 动效" hint="页面切换、导航指示器与启动按钮的位移/淡入动效。">
              <Switch
                checked={settings.animations !== false}
                onChange={(e) => update({ animations: e.target.checked })}
                color="primary"
              />
            </Row>

            <Row label="启动后最小化启动器" hint="游戏窗口拉起后自动收起启动器，避免遮挡画面。">
              <Switch
                checked={!!settings.closeOnLaunch}
                onChange={(e) => update({ closeOnLaunch: e.target.checked })}
                color="primary"
              />
            </Row>
          </GlassCard>
        </Box>

        <GlassCard sx={{ width: 320, flexShrink: 0, p: 2.6 }}>
          <SectionLabel>实时预览</SectionLabel>
          <Box
            sx={{
              mt: 2,
              borderRadius: '16px',
              border: '1px solid rgba(255,255,255,.08)',
              background:
                'linear-gradient(150deg, rgba(255,255,255,.07), rgba(255,255,255,.02)), radial-gradient(120% 90% at 0% 0%, ' +
                alpha(accent, 0.16) +
                ', transparent 60%)',
              p: 2.2
            }}
          >
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2, mb: 2 }}>
              <Box
                sx={{
                  width: 26,
                  height: 26,
                  borderRadius: '8px',
                  background: `linear-gradient(145deg, ${accent}, ${alpha(accent, 0.55)})`
                }}
              />
              <Typography sx={{ fontSize: 12.5, fontWeight: 650 }}>NeoRaven</Typography>
              <Box sx={{ flex: 1 }} />
              <Chip label="v1.0" size="small" sx={{ bgcolor: alpha(accent, 0.16), color: accent }} />
            </Box>

            <Typography variant="h4" sx={{ fontSize: 19, mb: 0.6 }}>
              准备好出发了吗
            </Typography>
            <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.42)', mb: 2 }}>
              1.8.9 · Forge · Mixin
            </Typography>

            <Button fullWidth variant="contained" sx={{ mb: 1.2, bgcolor: accent, color: '#1a1220' }}>
              启动游戏
            </Button>
            <Box sx={{ display: 'flex', gap: 1 }}>
              <Button fullWidth size="small" variant="outlined" sx={{ borderColor: rgbaBorder(accent), color: accent }}>
                设置
              </Button>
              <Button fullWidth size="small" variant="text" sx={{ color: 'rgba(255,255,255,.55)' }}>
                日志
              </Button>
            </Box>

            <Box sx={{ mt: 2.2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.8 }}>
                <Typography sx={{ fontSize: 10.5, color: 'rgba(255,255,255,.4)' }}>正在同步资源</Typography>
                <Typography className="mono" sx={{ fontSize: 10.5, color: accent }}>
                  68%
                </Typography>
              </Box>
              <Box sx={{ height: 4, borderRadius: 3, background: 'rgba(255,255,255,.1)', overflow: 'hidden' }}>
                <Box sx={{ width: '68%', height: '100%', borderRadius: 3, background: accent }} />
              </Box>
            </Box>
          </Box>

          <Typography sx={{ fontSize: 10.5, color: 'rgba(255,255,255,.3)', mt: 2, lineHeight: 1.7 }}>
            提示：默认主题为粉色 #FF9BB2，可在上方任意切换，偏好会自动保存到本地配置。
          </Typography>
        </GlassCard>
      </Box>
    </Box>
  )
}

function rgbaBorder(hex) {
  return alpha(hex, 0.35)
}
