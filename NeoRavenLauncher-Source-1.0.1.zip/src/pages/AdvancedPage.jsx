import React, { useState } from 'react'
import { Box, Button, Slider, Switch, TextField, Typography, alpha, Tooltip, IconButton } from '@mui/material'
import CoffeeRoundedIcon from '@mui/icons-material/CoffeeRounded'
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded'
import FolderOpenRoundedIcon from '@mui/icons-material/FolderOpenRounded'
import api from '../api'
import { GlassCard, PageHeader, Row, SectionLabel, Pill } from '../components/ui'

export default function AdvancedPage({ settings, update, java, setJava }) {
  const [checking, setChecking] = useState(false)
  const accent = settings.accent

  const detect = async (customPath) => {
    setChecking(true)
    try {
      const info = await api.detectJava(customPath ?? settings.javaPath)
      setJava(info)
    } finally {
      setChecking(false)
    }
  }

  const chooseJava = async () => {
    const file = await api.pickJava()
    if (file) {
      await update({ javaPath: file })
      await detect(file)
    }
  }

  const compatible = java && java.major === 8

  return (
    <Box sx={{ pb: 2 }}>
      <PageHeader title="高级选项" subtitle="运行时、内存与启动参数 · 面向进阶用户" />

      <Box sx={{ display: 'flex', gap: 2.5, alignItems: 'flex-start' }}>
        <Box sx={{ flex: 1, minWidth: 0 }}>
          <GlassCard sx={{ p: 2.8, mb: 2.5 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 1.6 }}>
              <SectionLabel>Java 运行时</SectionLabel>
              <Box sx={{ flex: 1 }} />
              <Pill color={compatible ? '#7ED9A6' : '#FFC978'}>
                {compatible ? '已就绪' : java && java.path ? '版本不兼容' : '未检测到'}
              </Pill>
            </Box>

            <Box
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 1.6,
                p: 1.8,
                borderRadius: '14px',
                border: '1px solid rgba(255,255,255,.07)',
                background: 'rgba(255,255,255,.03)'
              }}
            >
              <Box
                sx={{
                  width: 34,
                  height: 34,
                  borderRadius: '10px',
                  display: 'grid',
                  placeItems: 'center',
                  background: alpha(accent, 0.14),
                  border: `1px solid ${alpha(accent, 0.24)}`
                }}
              >
                <CoffeeRoundedIcon sx={{ fontSize: 17, color: accent }} />
              </Box>
              <Box sx={{ minWidth: 0, flex: 1 }}>
                <Typography sx={{ fontSize: 12.5, fontWeight: 600 }}>
                  {java && java.version ? `Java ${java.version}` : '未检测到 Java 8'}
                </Typography>
                <Tooltip title={(java && java.path) || '未找到可用于启动的 Java'}>
                  <Typography
                    className="mono"
                    sx={{
                      fontSize: 10.5,
                      color: 'rgba(255,255,255,.38)',
                      mt: 0.3,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      direction: 'rtl',
                      textAlign: 'left'
                    }}
                  >
                    {(java && java.path) || '—'}
                  </Typography>
                </Tooltip>
              </Box>
              <IconButton size="small" onClick={() => detect()} disabled={checking} sx={{ color: 'rgba(255,255,255,.55)' }}>
                <RefreshRoundedIcon sx={{ fontSize: 16, animation: checking ? 'spin 1s linear infinite' : 'none' }} />
              </IconButton>
              <Button size="small" variant="outlined" onClick={chooseJava} sx={{ borderColor: alpha(accent, 0.3), color: accent }}>
                指定路径
              </Button>
            </Box>

            <Typography sx={{ fontSize: 10.8, color: 'rgba(255,255,255,.3)', mt: 1.4, lineHeight: 1.7 }}>
              Minecraft 1.8.9 + Forge 必须使用 Java 8（不支持 Java 9 及以上）。启动器会优先使用已安装的 JDK8，找不到时自动下载
              Adoptium JRE 8 到数据根目录下的 runtime 文件夹。
            </Typography>

            <Row label="自动下载 Java 8" hint="未检测到兼容运行时自动下载并解压，约 40 MB。" sx={{ mt: 1.2 }}>
              <Switch checked={settings.autoJava !== false} onChange={(e) => update({ autoJava: e.target.checked })} />
            </Row>
          </GlassCard>

          <GlassCard sx={{ p: 2.8 }}>
            <SectionLabel sx={{ mb: 1 }}>内存与性能</SectionLabel>

            <Row label="最大堆内存" hint="4 GB 适合原版 + 轻量模组；整合包建议 6-8 GB，过高反而会增加 GC 压力。">
              <Typography className="mono" sx={{ fontSize: 12, color: accent, width: 56, textAlign: 'right' }}>
                {((settings.memoryMb || 4096) / 1024).toFixed(1)} GB
              </Typography>
              <Box sx={{ width: 190, pr: 1 }}>
                <Slider
                  min={1024}
                  max={16384}
                  step={512}
                  value={settings.memoryMb || 4096}
                  valueLabelDisplay="auto"
                  valueLabelFormat={(v) => `${(v / 1024).toFixed(1)}G`}
                  onChange={(_e, v) => update({ memoryMb: v })}
                  marks={[
                    { value: 2048, label: '2G' },
                    { value: 4096, label: '4G' },
                    { value: 8192, label: '8G' },
                    { value: 16384, label: '16G' }
                  ]}
                  sx={{ '& .MuiSlider-markLabel': { fontSize: 9.5, color: 'rgba(255,255,255,.28)' } }}
                />
              </Box>
            </Row>

            <Row label="全屏启动" hint="以独占全屏方式拉起游戏窗口。">
              <Switch checked={!!settings.fullscreen} onChange={(e) => update({ fullscreen: e.target.checked })} />
            </Row>

            {!settings.fullscreen && (
              <Row label="窗口分辨率" hint="窗口模式下的游戏画面尺寸。">
                <TextField
                  value={settings.width}
                  onChange={(e) => update({ width: Math.max(854, Number(e.target.value.replace(/\D/g, '')) || 1280) })}
                  sx={{ width: 84 }}
                  inputProps={{ style: { textAlign: 'center', fontSize: 12 } }}
                />
                <Typography sx={{ color: 'rgba(255,255,255,.3)', fontSize: 12 }}>×</Typography>
                <TextField
                  value={settings.height}
                  onChange={(e) => update({ height: Math.max(480, Number(e.target.value.replace(/\D/g, '')) || 720) })}
                  sx={{ width: 84 }}
                  inputProps={{ style: { textAlign: 'center', fontSize: 12 } }}
                />
              </Row>
            )}

            <Box sx={{ pt: 1.6, borderTop: '1px solid rgba(255,255,255,.055)' }}>
              <Typography sx={{ fontSize: 13.5, fontWeight: 560, mb: 0.4 }}>JVM 参数</Typography>
              <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.4)', mb: 1.2 }}>
                追加到 java 命令行，空格分隔。留空使用默认（G1GC + UTF-8）。
              </Typography>
              <TextField
                fullWidth
                multiline
                minRows={2}
                defaultValue={settings.jvmArgs}
                onBlur={(e) => update({ jvmArgs: e.target.value })}
                className="mono"
                inputProps={{ style: { fontSize: 11.5, fontFamily: 'ui-monospace, monospace' } }}
                placeholder="-XX:+UseG1GC -Dfile.encoding=UTF-8"
              />
            </Box>
          </GlassCard>
        </Box>

        <GlassCard sx={{ width: 300, flexShrink: 0, p: 2.6 }} glow={accent}>
          <SectionLabel>启动概览</SectionLabel>
          <Box sx={{ mt: 2, display: 'flex', flexDirection: 'column', gap: 1.5 }}>
            {[
              ['客户端', 'NeoRaven 1.0.0'],
              ['游戏版本', 'Minecraft 1.8.9'],
              ['模组加载器', 'Forge 11.15.1.2318'],
              ['注入方式', 'Mixin 0.7.11'],
              ['账户模式', '离线 (legacy)'],
              ['最大内存', `${((settings.memoryMb || 4096) / 1024).toFixed(1)} GB`]
            ].map(([k, v]) => (
              <Box key={k} sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.4)' }}>{k}</Typography>
                <Typography className="mono" sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.8)' }}>
                  {v}
                </Typography>
              </Box>
            ))}
          </Box>

          <Box
            sx={{
              mt: 2.4,
              p: 1.5,
              borderRadius: '12px',
              background: alpha(accent, 0.08),
              border: `1px solid ${alpha(accent, 0.18)}`
            }}
          >
            <Typography sx={{ fontSize: 10.8, color: alpha(accent, 0.9), lineHeight: 1.7 }}>
              首次启动将自动完成 1.8.9 原版 + Forge + 客户端注入，耗时取决于网络，通常 3-6 分钟。
            </Typography>
          </Box>

          <Button
            fullWidth
            size="small"
            variant="outlined"
            startIcon={<FolderOpenRoundedIcon sx={{ fontSize: 15 }} />}
            onClick={() => api.openPath(settings.rootDir)}
            sx={{ mt: 2, borderColor: 'rgba(255,255,255,.12)', color: 'rgba(255,255,255,.6)' }}
          >
            查看运行数据
          </Button>
        </GlassCard>
      </Box>
    </Box>
  )
}
