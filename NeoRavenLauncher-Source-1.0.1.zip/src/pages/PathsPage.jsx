import React from 'react'
import { Box, Button, IconButton, Tooltip, Typography, alpha } from '@mui/material'
import FolderOpenRoundedIcon from '@mui/icons-material/FolderOpenRounded'
import EditRoundedIcon from '@mui/icons-material/EditRounded'
import StorageRoundedIcon from '@mui/icons-material/StorageRounded'
import SportsEsportsRoundedIcon from '@mui/icons-material/SportsEsportsRounded'
import PaletteRoundedIcon from '@mui/icons-material/PaletteRounded'
import SaveRoundedIcon from '@mui/icons-material/SaveRounded'
import ExtensionRoundedIcon from '@mui/icons-material/ExtensionRounded'
import PhotoCameraRoundedIcon from '@mui/icons-material/PhotoCameraRounded'
import RestartAltRoundedIcon from '@mui/icons-material/RestartAltRounded'
import api from '../api'
import { GlassCard, PageHeader, SectionLabel } from '../components/ui'

const FIELDS = [
  {
    key: 'rootDir',
    label: '数据根目录',
    icon: StorageRoundedIcon,
    hint: '所有游戏文件、运行库与日志的存放位置，建议放在空间充足的磁盘。'
  },
  {
    key: 'gameDir',
    label: '游戏文件夹 (.minecraft)',
    icon: SportsEsportsRoundedIcon,
    hint: 'version、mods、config 等目录的父级；使用独立目录可避免污染官方启动器。'
  },
  {
    key: 'resourcePacksDir',
    label: '材质包文件夹',
    icon: PaletteRoundedIcon,
    hint: 'resourcepacks，放入 zip 材质包后可在游戏内启用。'
  },
  {
    key: 'savesDir',
    label: '存档文件夹',
    icon: SaveRoundedIcon,
    hint: 'saves，单人存档所在目录。'
  },
  {
    key: 'modsDir',
    label: '模组文件夹',
    icon: ExtensionRoundedIcon,
    hint: 'mods，NeoRaven.jar 会自动注入到这里。'
  },
  {
    key: 'screenshotsDir',
    label: '截图文件夹',
    icon: PhotoCameraRoundedIcon,
    hint: 'screenshots，游戏内截图默认保存位置。'
  }
]

export default function PathsPage({ settings, update }) {
  const pick = async (field) => {
    const dir = await api.pickFolder({ title: `选择${field.label}`, current: settings[field.key] })
    if (dir) await update({ [field.key]: dir })
  }

  return (
    <Box sx={{ pb: 2 }}>
      <PageHeader
        title="目录设置"
        subtitle="自定义文件存放位置 · 所有改动即时写入配置文件"
        action={
          <Button
            size="small"
            startIcon={<RestartAltRoundedIcon sx={{ fontSize: 15 }} />}
            onClick={() => {
              const root = settings.rootDir
              update({
                gameDir: `${root}/.minecraft`.replace(/\//g, api.platform === 'win32' ? '\\' : '/'),
                resourcePacksDir: `${root}/.minecraft/resourcepacks`.replace(/\//g, api.platform === 'win32' ? '\\' : '/'),
                savesDir: `${root}/.minecraft/saves`.replace(/\//g, api.platform === 'win32' ? '\\' : '/'),
                modsDir: `${root}/.minecraft/mods`.replace(/\//g, api.platform === 'win32' ? '\\' : '/'),
                screenshotsDir: `${root}/.minecraft/screenshots`.replace(/\//g, api.platform === 'win32' ? '\\' : '/')
              })
            }}
            sx={{ color: 'rgba(255,255,255,.55)' }}
          >
            恢复默认子目录
          </Button>
        }
      />

      <GlassCard sx={{ p: 2.9 }} glow={settings.accent}>
        <SectionLabel sx={{ mb: 1.4 }}>文件位置</SectionLabel>
        {FIELDS.map((field, index) => {
          const Icon = field.icon
          return (
            <Box
              key={field.key}
              sx={{
                display: 'flex',
                alignItems: 'center',
                gap: 1.8,
                py: 1.75,
                borderTop: index === 0 ? '1px solid rgba(255,255,255,.055)' : '1px solid rgba(255,255,255,.055)'
              }}
            >
              <Box
                sx={{
                  width: 34,
                  height: 34,
                  borderRadius: '10px',
                  flexShrink: 0,
                  display: 'grid',
                  placeItems: 'center',
                  background: 'rgba(255,255,255,.05)',
                  border: '1px solid rgba(255,255,255,.07)'
                }}
              >
                <Icon sx={{ fontSize: 17, color: alpha(settings.accent, 0.85) }} />
              </Box>

              <Box sx={{ minWidth: 0, flex: 1 }}>
                <Typography sx={{ fontSize: 13, fontWeight: 600 }}>{field.label}</Typography>
                <Tooltip title={settings[field.key] || ''} placement="bottom-start" enterDelay={600}>
                  <Typography
                    className="mono"
                    sx={{
                      fontSize: 11,
                      color: 'rgba(255,255,255,.4)',
                      mt: 0.35,
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      direction: 'rtl',
                      textAlign: 'left'
                    }}
                  >
                    {settings[field.key] || '未设置'}
                  </Typography>
                </Tooltip>
                <Typography sx={{ fontSize: 10.5, color: 'rgba(255,255,255,.26)', mt: 0.3 }}>{field.hint}</Typography>
              </Box>

              <Box sx={{ display: 'flex', gap: 0.8, flexShrink: 0 }}>
                <Tooltip title="在资源管理器中打开">
                  <IconButton size="small" onClick={() => api.openPath(settings[field.key])} sx={{ color: 'rgba(255,255,255,.5)' }}>
                    <FolderOpenRoundedIcon sx={{ fontSize: 17 }} />
                  </IconButton>
                </Tooltip>
                <Button
                  size="small"
                  variant="outlined"
                  startIcon={<EditRoundedIcon sx={{ fontSize: 14 }} />}
                  onClick={() => pick(field)}
                  sx={{
                    borderColor: alpha(settings.accent, 0.28),
                    color: alpha(settings.accent, 0.95),
                    '&:hover': { borderColor: alpha(settings.accent, 0.5), background: alpha(settings.accent, 0.08) }
                  }}
                >
                  更改
                </Button>
              </Box>
            </Box>
          )
        })}
      </GlassCard>

      <Box sx={{ display: 'flex', gap: 1.2, mt: 2.2 }}>
        <Button size="small" variant="contained" onClick={() => api.openPath(settings.gameDir)}>
          打开游戏文件夹
        </Button>
        <Button size="small" variant="text" onClick={() => api.openPath(settings.modsDir)} sx={{ color: 'rgba(255,255,255,.55)' }}>
          打开 mods
        </Button>
        <Button onClick={() => api.openPath(settings.rootDir)} size="small" variant="text" sx={{ color: 'rgba(255,255,255,.55)' }}>
          打开数据根目录
        </Button>
      </Box>
    </Box>
  )
}
