import React, { useState } from 'react'
import { Slider, Switch } from '@mui/material'
import api from '../api'
import { MUI_COLORS } from '../theme'
import Logo from '../components/Logo'
import { renderIconPng } from '../components/iconRender'

function ripple(e) {
  const el = e.currentTarget
  const rect = el.getBoundingClientRect()
  const size = Math.max(rect.width, rect.height) * 0.6
  const span = document.createElement('span')
  span.className = 'ripple'
  span.style.left = e.clientX - rect.left - size / 2 + 'px'
  span.style.top = e.clientY - rect.top - size / 2 + 'px'
  span.style.width = span.style.height = size + 'px'
  el.appendChild(span)
  setTimeout(() => span.remove(), 540)
}

function PathRow({ label, sub, value, onPick }) {
  return (
    <div style={{ marginBottom: 10 }}>
      <div className="setting-row" style={{ minHeight: 34, paddingBottom: 0 }}>
        <div>
          <div className="label">{label}</div>
          {sub && <div className="sub">{sub}</div>}
        </div>
      </div>
      <div className="path-row">
        <input className="path-input" value={value || ''} readOnly />
        <button className="path-btn" onClick={onPick} onPointerDown={ripple}>
          更改
        </button>
        <button className="path-btn" onClick={() => api.openPath(value)} onPointerDown={ripple}>
          打开
        </button>
      </div>
    </div>
  )
}

export default function SettingsPage({ settings, save, meta, java, setJava, iconColor, setIconColor, hwidMasked, updateState }) {
  const [accent, setAccent] = useState(settings.accent || '#FF9BB2')
  const [detecting, setDetecting] = useState(false)
  const [iconMsg, setIconMsg] = useState('')
  const [renameValue, setRenameValue] = useState(settings.username || '')
  const [renameMsg, setRenameMsg] = useState('')
  const [checkingUpdate, setCheckingUpdate] = useState(false)
  const iconTimer = React.useRef(null)

  /* 主题色 = 界面强调色 + 应用图标色（窗口图标 / 桌面快捷方式） */
  const pickColor = (c, { immediate = false } = {}) => {
    // 1) UI 立即响应，不做任何等待
    setAccent(c)
    setIconColor(c)
    document.documentElement.style.setProperty('--accent', c)
    // 2) 持久化 + 原生图标，防抖合并（拖动取色器时不刷屏）
    if (iconTimer.current) clearTimeout(iconTimer.current)
    const run = async () => {
      await save({ accent: c, iconColor: c })
      try {
        const png = renderIconPng(c, 256)
        const r = await api.applyIconColor(png, c)
        setIconMsg(r && r.ok ? '图标已同步' : (r && r.error) || '')
      } catch (e) {
        setIconMsg('图标应用失败')
      }
    }
    if (immediate) run()
    else iconTimer.current = setTimeout(run, 260)
  }

  const doRename = async () => {
    const n = renameValue.trim()
    if (!n) return
    const r = await api.renameUser(n)
    setRenameMsg(r && r.ok ? (r.cloud ? '已保存并同步到云端' : '已保存（云端同步失败，本机仍有效）') : r.error || '保存失败')
  }

  const doCheckUpdate = async () => {
    setCheckingUpdate(true)
    await api.checkUpdates()
    setCheckingUpdate(false)
  }

  const pick = (key, title) => async () => {
    const dir = await api.pickFolder({ title, current: settings[key] })
    if (dir) await save({ [key]: dir })
  }

  const detect = async () => {
    setDetecting(true)
    const info = await api.detectJava(settings.javaPath)
    setJava(info || { found: false })
    if (info && info.path) await save({ javaPath: info.path })
    setDetecting(false)
  }

  const currentVersionName = (() => {
    const rels = (updateState && updateState.releases) || []
    const tag = (updateState && updateState.current) || settings.clientVersion || ''
    const rel = rels.find((r) => r.tag === tag) || rels[0]
    return rel ? rel.name : tag || '未安装'
  })()

  return (
    <div className="page">
      <div className="settings-grid">
        <div>
          <div className="section">
            <div className="section-title">主题色</div>
            <div className="icon-preview-row">
              <Logo size={44} color={iconColor} />
              <div>
                <div className="label">界面强调色与应用图标</div>
                <div className="sub">一处修改，同时作用于界面、窗口图标与桌面图标</div>
              </div>
            </div>
            <div className="swatch-grid">
              {MUI_COLORS.map((c) => (
                <button
                  key={c.value + c.name}
                  className={`swatch${accent.toUpperCase() === c.value.toUpperCase() ? ' selected' : ''}`}
                  style={{ background: c.value }}
                  title={c.name}
                  onClick={() => pickColor(c.value, { immediate: true })}
                />
              ))}
            </div>
            <div className="setting-row" style={{ marginTop: 8 }}>
              <div>
                <div className="label">自定义颜色</div>
                <div className="sub">{iconMsg || '取色后立即同步到界面与图标'}</div>
              </div>
              <input
                type="color"
                value={accent}
                onChange={(e) => pickColor(e.target.value)}
                onBlur={(e) => pickColor(e.target.value, { immediate: true })}
                style={{ width: 48, height: 34, border: 'none', borderRadius: 10, background: 'transparent', cursor: 'pointer' }}
              />
            </div>
          </div>

          <div className="section">
            <div className="section-title">用户</div>
            <div className="setting-row">
              <div>
                <div className="label">用户名</div>
                <div className="sub">
                  机器码 {hwidMasked || '—'} · 重装后自动识别
                </div>
              </div>
              <input
                className="text-input"
                value={renameValue}
                onChange={(e) => setRenameValue(e.target.value)}
                placeholder="Steve"
                maxLength={16}
              />
            </div>
            <div className="setting-row" style={{ minHeight: 36 }}>
              <div>
                <div className="sub">{renameMsg || '修改后会同步到云端，与本机机器码绑定'}</div>
              </div>
              <button className="path-btn" onClick={doRename} onPointerDown={ripple}>
                保存用户名
              </button>
            </div>
          </div>
        </div>

        <div>
          <div className="section">
            <div className="section-title">客户端版本</div>
            <div className="setting-row">
              <div>
                <div className="label">{currentVersionName}</div>
                <div className="sub">
                  每次启动自动检测 GitHub Release 并更新
                  {updateState && updateState.updated ? ' · 刚刚已更新' : ''}
                </div>
              </div>
              <button className="path-btn" onClick={doCheckUpdate} disabled={checkingUpdate} onPointerDown={ripple}>
                {checkingUpdate || (updateState && updateState.checking) ? '检查中…' : '检查更新'}
              </button>
            </div>
            <div className="setting-row">
              <div>
                <div className="label">启动时自动更新</div>
                <div className="sub">关闭后保持当前选择的版本</div>
              </div>
              <Switch
                size="small"
                checked={settings.autoUpdate !== false}
                onChange={(e) => save({ autoUpdate: e.target.checked })}
                sx={{ color: 'rgba(255,255,255,.35)' }}
              />
            </div>
          </div>

          <div className="section">
            <div className="section-title">文件位置</div>
            <PathRow label="数据根目录" value={settings.rootDir} onPick={pick('rootDir', '选择数据根目录')} />
            <PathRow label="游戏文件夹" sub=".minecraft" value={settings.gameDir} onPick={pick('gameDir', '选择游戏文件夹')} />
            <PathRow
              label="材质包文件夹"
              sub="resourcepacks"
              value={settings.resourcePacksDir}
              onPick={pick('resourcePacksDir', '选择材质包文件夹')}
            />
          </div>

          <div className="section">
            <div className="section-title">游戏参数</div>
            <div className="setting-row" style={{ alignItems: 'flex-start' }}>
              <div>
                <div className="label">内存分配</div>
                <div className="sub">推荐 2048 – 4096 MB</div>
              </div>
              <div style={{ width: 168, display: 'flex', flexDirection: 'column', alignItems: 'stretch', gap: 2 }}>
                <Slider
                  min={1024}
                  max={8192}
                  step={512}
                  value={settings.memoryMb || 4096}
                  onChange={(_e, v) => save({ memoryMb: v })}
                  valueLabelDisplay="auto"
                  valueLabelFormat={(v) => `${v} MB`}
                  size="small"
                  sx={{ color: accent, py: 1 }}
                />
                <span style={{ fontSize: 11.5, color: 'rgba(255,255,255,0.55)', textAlign: 'right' }}>
                  {settings.memoryMb || 4096} MB
                </span>
              </div>
            </div>
            <div className="setting-row">
              <div>
                <div className="label">游戏启动后隐藏启动器</div>
                <div className="sub">默认关闭，启动后保持启动器窗口可见</div>
              </div>
              <Switch
                size="small"
                checked={!!settings.closeOnLaunch}
                onChange={(e) => save({ closeOnLaunch: e.target.checked })}
                sx={{ color: 'rgba(255,255,255,.35)' }}
              />
            </div>
          </div>

          <div className="section">
            <div className="section-title">Java 运行时</div>
            <div className="setting-row">
              <div>
                <div className="label">Java 路径</div>
                <div className="sub">
                  {java && java.found ? `已检测到 ${java.version || ''}` : '未检测到，可自动下载 Java 8'}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button className="path-btn" onClick={detect} disabled={detecting} onPointerDown={ripple}>
                  {detecting ? '检测中…' : '检测'}
                </button>
                <button
                  className="path-btn"
                  onClick={async () => {
                    const f = await api.pickJava()
                    if (f) {
                      await save({ javaPath: f })
                      const info = await api.detectJava(f)
                      setJava(info || { found: false })
                    }
                  }}
                  onPointerDown={ripple}
                >
                  手动选择
                </button>
              </div>
            </div>
            {settings.javaPath && (
              <div className="path-row">
                <input className="path-input" value={settings.javaPath} readOnly />
              </div>
            )}
          </div>

          <div className="section" style={{ opacity: 0.65 }}>
            <div className="section-title">关于</div>
            <div className="about-line">
              <strong>NeoRavenLauncher</strong>
              <span>v{meta.version}</span>
            </div>
            <div className="about-line">
              <span>
                {meta.platform} · Electron {meta.electron} · {meta.material === 'acrylic' ? '系统亚克力' : meta.material === 'vibrancy' ? 'macOS 毛玻璃' : '模糊'}窗口
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
