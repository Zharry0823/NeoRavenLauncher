import React, { useEffect, useRef, useState } from 'react'
import api from '../api'

function ripple(e) {
  const el = e.currentTarget
  const rect = el.getBoundingClientRect()
  const size = Math.max(rect.width, rect.height) * 0.6
  const span = document.createElement('span')
  span.className = 'ripple'
  span.style.left = e.clientX - rect.left - size / 2 + 'px'
  span.style.top = e.clientY - rect.top - size / 2 + 'px'
  span.style.width = span.style.height = size + 'px'
  el.appendChild(span)
  setTimeout(() => span.remove(), 540)
}

function formatSize(n) {
  if (!n) return ''
  if (n > 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
  return `${Math.max(1, Math.round(n / 1024))} KB`
}

function formatDate(iso) {
  if (!iso) return ''
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}

export default function HomePage({ settings, save, meta, java, updateState }) {
  const [launching, setLaunching] = useState(false)
  const [phase, setPhase] = useState({ percent: 0, detail: '' })
  const [logs, setLogs] = useState([])
  const [logOpen, setLogOpen] = useState(false)
  const [showVersion, setShowVersion] = useState(false)
  const [picking, setPicking] = useState('')
  const logRef = useRef(null)

  const releases = (updateState && updateState.releases) || []
  const currentTag = (updateState && updateState.current) || settings.clientVersion || ''
  const current = releases.find((r) => r.tag === currentTag) || releases[0] || null
  const currentName = current ? current.name : 'NeoRaven'
  const checking = updateState && updateState.checking

  useEffect(() => {
    const offLog = api.onLog((line) => {
      setLogs((l) => {
        const next = [...l, line]
        return next.length > 400 ? next.slice(-400) : next
      })
    })
    const offState = api.onState((s) => {
      setPhase({ percent: s.percent || 0, detail: s.detail || '' })
      if (s.phase === 'running' || s.phase === 'error' || s.phase === 'idle') {
        setLaunching(false)
      } else {
        setLaunching(true)
      }
    })
    return () => {
      offLog && offLog()
      offState && offState()
    }
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logs])

  const doLaunch = async () => {
    if (launching) return
    setLaunching(true)
    setPhase({ percent: 0, detail: '正在准备…' })
    const r = await api.launch()
    if (r && r.ok === false) {
      setLaunching(false)
      setPhase({ percent: 0, detail: r.error || '启动失败' })
    }
  }

  const doCancel = async () => {
    await api.cancel()
    setLaunching(false)
  }

  const pickVersion = async (tag) => {
    if (picking) return
    setPicking(tag)
    const r = await api.selectVersion(tag)
    setPicking('')
    if (r && r.ok !== false) setShowVersion(false)
  }

  const username = (settings.username || 'Steve').trim()

  return (
    <div className="page">
      <div className="home-grid">
        <div className="hero">
          <div className="greet">欢迎回来，{username}</div>
          <h1>NeoRaven 客户端</h1>
          <div className="hero-meta">
            {checking ? (
              <span className="chip">正在检查更新…</span>
            ) : (
              <span className="chip">{currentName}</span>
            )}
            {updateState && updateState.updated && <span className="chip chip-accent">已更新到最新</span>}
            {updateState && updateState.error && <span className="chip">更新检查失败</span>}
          </div>
        </div>

        <div className="launch-zone">
          {(phase.detail || launching) && (
            <>
              <div className="status-line">
                {launching && <span className="spin-dot" />}
                <span>{phase.detail}</span>
              </div>
              {launching && (
                <div className="progress-track">
                  <div className="progress-fill" style={{ width: `${Math.max(4, Math.min(100, phase.percent))}%` }} />
                </div>
              )}
            </>
          )}

          <button className="btn-launch" onClick={doLaunch} onPointerDown={ripple} disabled={launching}>
            {launching ? '启动中…' : '启动'}
          </button>

          <button className="btn-tonal" onClick={() => setShowVersion(true)} onPointerDown={ripple}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M4 7h16M4 12h16M4 17h10" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            版本选项 · {currentName}
          </button>

          {logs.length > 0 && (
            <div className="log-drawer">
              <div className="log-head" onClick={() => setLogOpen((v) => !v)}>
                <span>启动日志 ({logs.length})</span>
                <span>{logOpen ? '收起' : '展开'}</span>
              </div>
              {logOpen && (
                <div className="log-body" ref={logRef}>
                  {logs.join('')}
                </div>
              )}
            </div>
          )}

          {launching && (
            <button
              className="btn-tonal"
              onClick={doCancel}
              style={{ height: 38, fontSize: 12.5, background: 'rgba(255,255,255,0.05)' }}
            >
              取消启动
            </button>
          )}
        </div>
      </div>

      {showVersion && (
        <div className="modal-mask" onClick={() => setShowVersion(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>版本选项</h3>
            {releases.length === 0 && (
              <div style={{ padding: '10px 8px 16px', fontSize: 12.5, color: 'rgba(255,255,255,0.55)' }}>
                {checking ? '正在从 GitHub 获取版本列表…' : '暂无可用版本，请检查网络后重新打开'}
              </div>
            )}
            {releases.map((r) => (
              <div
                key={r.tag}
                className={`opt${r.tag === currentTag ? ' selected' : ''}`}
                onClick={() => pickVersion(r.tag)}
              >
                <div>
                  <div style={{ fontWeight: 600 }}>{r.name}</div>
                  <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', marginTop: 2 }}>
                    {formatDate(r.publishedAt)}
                    {r.jar && r.jar.size ? ` · ${formatSize(r.jar.size)}` : ''}
                    {r.tag === currentTag ? ' · 当前使用' : ''}
                    {picking === r.tag ? ' · 切换中…' : ''}
                  </div>
                </div>
                {r.tag === currentTag && (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M5 12.5l4.5 4.5L19 7.5" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                )}
              </div>
            ))}
            <div className="actions">
              <button onClick={() => setShowVersion(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
