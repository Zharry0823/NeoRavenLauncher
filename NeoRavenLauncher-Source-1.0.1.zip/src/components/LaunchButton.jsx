import React from 'react'
import { Box, ButtonBase, Typography, alpha } from '@mui/material'
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded'
import CloseRoundedIcon from '@mui/icons-material/CloseRounded'
import { motion } from 'framer-motion'

export default function LaunchButton({ accent, running, percent = 0, onLaunch, onCancel, disabled }) {
  const R = 60
  const C = 2 * Math.PI * R
  const progress = Math.max(0, Math.min(100, percent))

  return (
    <Box sx={{ position: 'relative', width: 148, height: 148, display: 'grid', placeItems: 'center' }}>
      <Box
        sx={{
          position: 'absolute',
          inset: 0,
          borderRadius: '50%',
          background: `radial-gradient(circle at 50% 50%, ${alpha(accent, 0.22)} 0%, transparent 62%)`,
          filter: 'blur(2px)'
        }}
      />

      <motion.div
        animate={running ? { rotate: 360 } : { rotate: 0 }}
        transition={running ? { duration: 2.4, repeat: Infinity, ease: 'linear' } : { duration: 0.4 }}
        style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center' }}
      >
        <svg width={148} height={148} viewBox="0 0 148 148">
          <circle cx="74" cy="74" r={R} fill="none" stroke="rgba(255,255,255,.08)" strokeWidth="2.5" />
          {running && (
            <circle
              cx="74"
              cy="74"
              r={R}
              fill="none"
              stroke={accent}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeDasharray={`${C * 0.18} ${C}`}
              opacity="0.85"
            />
          )}
          {!running && progress > 0 && (
            <circle
              cx="74"
              cy="74"
              r={R}
              fill="none"
              stroke={accent}
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeDasharray={`${(progress / 100) * C} ${C}`}
              transform="rotate(-90 74 74)"
              style={{ transition: 'stroke-dasharray .3s ease' }}
            />
          )}
        </svg>
      </motion.div>

      <ButtonBase
        onClick={running ? onCancel : onLaunch}
        disabled={disabled}
        sx={{
          width: 108,
          height: 108,
          borderRadius: '50%',
          color: '#1a1220',
          background: `linear-gradient(150deg, ${alpha(accent, 0.98)} 0%, ${alpha(accent, 0.86)} 55%, ${alpha(accent, 0.72)} 100%)`,
          boxShadow: `0 16px 44px ${alpha(accent, 0.34)}, inset 0 1px 0 rgba(255,255,255,.55), inset 0 -12px 24px ${alpha('#000', 0.14)}`,
          transition: 'transform .22s cubic-bezier(.2,.8,.2,1), box-shadow .25s ease, filter .2s ease',
          '&:hover': {
            transform: 'translateY(-2px) scale(1.028)',
            boxShadow: `0 22px 54px ${alpha(accent, 0.46)}, inset 0 1px 0 rgba(255,255,255,.6)`
          },
          '&:active': { transform: 'scale(.975)' },
          '&.Mui-disabled': { filter: 'grayscale(.4)', opacity: 0.55 }
        }}
      >
        <Box sx={{ display: 'grid', placeItems: 'center' }}>
          {running ? (
            <CloseRoundedIcon sx={{ fontSize: 34, color: '#1a1220' }} />
          ) : (
            <PlayArrowRoundedIcon sx={{ fontSize: 44, color: '#1a1220', ml: 0.4 }} />
          )}
        </Box>
      </ButtonBase>

      <Typography
        sx={{
          position: 'absolute',
          bottom: -4,
          fontSize: 9.5,
          fontWeight: 700,
          letterSpacing: '.18em',
          color: 'rgba(255,255,255,.32)'
        }}
      >
        {running ? 'CANCEL' : 'LAUNCH'}
      </Typography>
    </Box>
  )
}
