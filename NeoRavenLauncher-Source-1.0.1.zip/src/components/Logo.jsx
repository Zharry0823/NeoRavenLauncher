import React from 'react'
import { SQUIRCLE, RAVEN } from '../iconPaths'

/* NeoRaven 官方矢量图标：超椭圆底 + 乌鸦剪影（NeoRaven-Icon-Kit-v1） */
export default function Logo({ size = 36, color = '#FF9BB2' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 1024 1024" style={{ display: 'block' }}>
      <path d={SQUIRCLE} fill={color} />
      <path d={RAVEN} fill="#FFFFFF" />
    </svg>
  )
}

export function RavenMark({ size = 22, color = 'currentColor' }) {
  return (
    <svg width={size} height={size} viewBox="225 250 574 524" style={{ display: 'block' }}>
      <path d={RAVEN} fill={color} />
    </svg>
  )
}
