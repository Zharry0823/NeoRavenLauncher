import { SQUIRCLE, RAVEN } from '../iconPaths'

/**
 * 在 canvas 上按给定颜色渲染图标，返回 PNG dataURL。
 * 用于窗口左上角图标 + 桌面快捷方式 .ico 的生成，与主题色完全解耦。
 */
export function renderIconPng(color = '#FF9BB2', size = 256) {
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const ctx = c.getContext('2d')
  const k = size / 1024
  ctx.clearRect(0, 0, size, size)
  ctx.save()
  ctx.scale(k, k)
  const sq = new Path2D(SQUIRCLE)
  const rv = new Path2D(RAVEN)
  ctx.fillStyle = color
  ctx.fill(sq)
  ctx.fillStyle = '#FFFFFF'
  ctx.fill(rv)
  ctx.restore()
  return c.toDataURL('image/png')
}

export const ICON_SWATCHES = [
  { name: '樱花粉', value: '#FF9BB2' },
  { name: '玫瑰红', value: '#F2739A' },
  { name: '琥珀橙', value: '#FFB74D' },
  { name: '柠檬黄', value: '#FFD54F' },
  { name: '青瓷绿', value: '#81C784' },
  { name: '天青蓝', value: '#64B5F6' },
  { name: '星黛紫', value: '#B39DDB' },
  { name: '石墨灰', value: '#90A4AE' }
]
