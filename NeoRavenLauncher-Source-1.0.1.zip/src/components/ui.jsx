import React from 'react'
import { Box, Typography, alpha } from '@mui/material'

export function GlassCard({ children, sx, hover = false, glow = null, ...rest }) {
  return (
    <Box
      className={hover ? 'card-hover' : undefined}
      sx={{
        position: 'relative',
        borderRadius: '20px',
        border: '1px solid rgba(255,255,255,.075)',
        background: 'linear-gradient(160deg, rgba(255,255,255,.055) 0%, rgba(255,255,255,.022) 55%, rgba(255,255,255,.012) 100%)',
        backdropFilter: 'blur(14px)',
        boxShadow: '0 18px 40px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.06)',
        overflow: 'hidden',
        ...sx
      }}
      {...rest}
    >
      {glow && (
        <Box
          sx={{
            position: 'absolute',
            width: 260,
            height: 260,
            borderRadius: '50%',
            top: -150,
            right: -60,
            background: glow,
            opacity: 0.14,
            filter: 'blur(60px)',
            pointerEvents: 'none'
          }}
        />
      )}
      <Box sx={{ position: 'relative', zIndex: 1, height: '100%' }}>{children}</Box>
    </Box>
  )
}

export function SectionLabel({ children, sx }) {
  return (
    <Typography
      sx={{
        fontSize: 10.5,
        fontWeight: 700,
        letterSpacing: '.16em',
        textTransform: 'uppercase',
        color: 'rgba(255,255,255,.35)',
        ...sx
      }}
    >
      {children}
    </Typography>
  )
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <Box sx={{ display: 'flex', alignItems: 'flex-end', gap: 2, pt: 1.5, pb: 2.6 }}>
      <Box>
        <Typography variant="h2" sx={{ fontSize: 25 }}>
          {title}
        </Typography>
        {subtitle && (
          <Typography sx={{ fontSize: 12.5, color: 'rgba(255,255,255,.45)', mt: 0.6, letterSpacing: '.01em' }}>
            {subtitle}
          </Typography>
        )}
      </Box>
      <Box sx={{ flex: 1 }} />
      {action}
    </Box>
  )
}

export function Row({ label, hint, children, align = 'center', sx }) {
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: align,
        gap: 2,
        py: 1.55,
        '& + &': { borderTop: '1px solid rgba(255,255,255,.055)' },
        ...sx
      }}
    >
      <Box sx={{ minWidth: 0, flex: 1 }}>
        <Typography sx={{ fontSize: 13.5, fontWeight: 560, letterSpacing: '.005em' }}>{label}</Typography>
        {hint && (
          <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.4)', mt: 0.35, lineHeight: 1.5 }}>{hint}</Typography>
        )}
      </Box>
      <Box sx={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: 1 }}>{children}</Box>
    </Box>
  )
}

export function Pill({ children, color, sx }) {
  return (
    <Box
      sx={{
        px: 1,
        height: 21,
        display: 'inline-flex',
        alignItems: 'center',
        gap: 0.6,
        borderRadius: '7px',
        fontSize: 10.5,
        fontWeight: 650,
        letterSpacing: '.02em',
        color: color || 'rgba(255,255,255,.62)',
        background: alpha(color || '#ffffff', 0.1),
        border: `1px solid ${alpha(color || '#ffffff', 0.16)}`,
        ...sx
      }}
    >
      {children}
    </Box>
  )
}
