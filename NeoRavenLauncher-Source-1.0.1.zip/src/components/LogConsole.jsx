import React, { useEffect, useRef } from 'react'
import { Box, Typography } from '@mui/material'

export default function LogConsole({ logs = [], height = 168 }) {
  const ref = useRef(null)

  useEffect(() => {
    const el = ref.current
    if (el) el.scrollTop = el.scrollHeight
  }, [logs])

  const text = logs.join('')

  return (
    <Box
      ref={ref}
      className="mono no-scrollbar"
      sx={{
        height,
        overflowY: 'auto',
        fontSize: 10.5,
        lineHeight: 1.75,
        color: 'rgba(255,255,255,.5)',
        whiteSpace: 'pre-wrap',
        wordBreak: 'break-all',
        px: 0.2
      }}
    >
      {logs.length === 0 ? (
        <Typography sx={{ fontSize: 11, color: 'rgba(255,255,255,.24)', fontFamily: 'inherit' }}>
          等待启动，日志将在此实时输出…
        </Typography>
      ) : (
        text.split('\n').map((line, i) => {
          let color = 'rgba(255,255,255,.5)'
          if (/error|exception|failed|错误|失败/i.test(line)) color = '#FF8A97'
          else if (/warn/i.test(line)) color = '#FFC978'
          else if (/\[launcher\]/.test(line)) color = '#9EC5FF'
          return (
            <div key={i} style={{ color }}>
              {line || '\u00a0'}
            </div>
          )
        })
      )}
    </Box>
  )
}
