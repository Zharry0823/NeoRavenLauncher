import React from 'react'
import { Box, Stack, Typography, Avatar, alpha } from '@mui/material'
import { motion, AnimatePresence } from 'framer-motion'
import HomeRoundedIcon from '@mui/icons-material/HomeRounded'
import PaletteRoundedIcon from '@mui/icons-material/PaletteRounded'
import FolderRoundedIcon from '@mui/icons-material/FolderRounded'
import TuneRoundedIcon from '@mui/icons-material/TuneRounded'
import InfoRoundedIcon from '@mui/icons-material/InfoRounded'
import Logo from './Logo'

const NAV = [
  { id: 'home', label: '主页', icon: HomeRoundedIcon },
  { id: 'appearance', label: '外观主题', icon: PaletteRoundedIcon },
  { id: 'paths', label: '目录设置', icon: FolderRoundedIcon },
  { id: 'advanced', label: '高级选项', icon: TuneRoundedIcon },
  { id: 'about', label: '关于', icon: InfoRoundedIcon }
]

export default function SideRail({ page, onChange, accent, animations = true, username }) {
  return (
    <Box
      sx={{
        width: 208,
        flexShrink: 0,
        borderRight: '1px solid rgba(255,255,255,.06)',
        py: 1.6,
        px: 1.5,
        display: 'flex',
        flexDirection: 'column',
        gap: 0.4
      }}
    >
      <Typography
        variant="caption"
        sx={{ px: 1.4, pb: 0.9, color: 'rgba(255,255,255,.34)', letterSpacing: '.16em', fontSize: 10, fontWeight: 600 }}
      >
        导航
      </Typography>

      {NAV.map((item, index) => {
        const Icon = item.icon
        const active = page === item.id
        return (
          <Box
            key={item.id}
            onClick={() => onChange(item.id)}
            sx={{
              position: 'relative',
              display: 'flex',
              alignItems: 'center',
              gap: 1.5,
              height: 40,
              px: 1.4,
              borderRadius: '12px',
              cursor: 'pointer',
              color: active ? '#fff' : 'rgba(255,255,255,.6)',
              transition: 'color .2s ease, background-color .2s ease',
              '&:hover': { color: '#fff', backgroundColor: active ? 'transparent' : 'rgba(255,255,255,.045)' }
            }}
          >
            {active && (
              <motion.div
                layoutId={animations ? 'nav-pill' : undefined}
                transition={{ type: 'spring', stiffness: 420, damping: 34 }}
                style={{
                  position: 'absolute',
                  inset: 0,
                  borderRadius: 12,
                  background: alpha(accent, 0.16),
                  border: `1px solid ${alpha(accent, 0.3)}`,
                  boxShadow: `inset 0 1px 0 rgba(255,255,255,.06)`
                }}
              />
            )}
            {active && (
              <Box
                sx={{
                  position: 'absolute',
                  left: -1.5,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  width: 3,
                  height: 18,
                  borderRadius: 2,
                  background: accent,
                  boxShadow: `0 0 12px ${accent}`
                }}
              />
            )}
            <Icon sx={{ fontSize: 18.5, color: active ? accent : 'inherit', position: 'relative', zIndex: 1 }} />
            <Typography
              sx={{ fontSize: 13, fontWeight: active ? 650 : 500, position: 'relative', zIndex: 1, letterSpacing: '.01em' }}
            >
              {item.label}
            </Typography>
          </Box>
        )
      })}

      <Box sx={{ flex: 1 }} />

      <Box
        sx={{
          mt: 1,
          p: 1.2,
          borderRadius: '14px',
          border: '1px solid rgba(255,255,255,.07)',
          background: 'linear-gradient(150deg, rgba(255,255,255,.055), rgba(255,255,255,.02))',
          display: 'flex',
          alignItems: 'center',
          gap: 1.2
        }}
      >
        <Avatar
          sx={{
            width: 28,
            height: 28,
            fontSize: 12,
            fontWeight: 700,
            bgcolor: alpha(accent, 0.24),
            color: accent,
            border: `1px solid ${alpha(accent, 0.35)}`
          }}
        >
          {(username || 'S').slice(0, 1).toUpperCase()}
        </Avatar>
        <Box sx={{ minWidth: 0 }}>
          <Typography sx={{ fontSize: 12, fontWeight: 600, lineHeight: 1.3 }} noWrap>
            {username || 'Steve'}
          </Typography>
          <Typography sx={{ fontSize: 10, color: 'rgba(255,255,255,.4)', lineHeight: 1.4 }}>离线账户</Typography>
        </Box>
        <Box sx={{ flex: 1 }} />
        <Logo size={16} accent={accent} radius={0.32} />
      </Box>
    </Box>
  )
}
