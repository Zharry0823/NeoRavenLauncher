import React from 'react'
import Logo from './Logo'

export default function TitleBar({ iconColor = '#FF9BB2' }) {
  return (
    <header className="titlebar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <Logo size={18} color={iconColor} />
        <span style={{ fontSize: 12, fontWeight: 600, letterSpacing: 0.2, color: 'rgba(255,255,255,0.7)' }}>
          NeoRavenLauncher
        </span>
      </div>
      <div className="win-actions">
        <button className="win-btn" onClick={() => window.neoraven && window.neoraven.minimize()} title="最小化" aria-label="最小化">
          <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
            <rect x="6" y="11" width="12" height="2" rx="0.6" fill="currentColor" />
          </svg>
        </button>
        <button className="win-btn close" onClick={() => window.neoraven && window.neoraven.close()} title="关闭" aria-label="关闭">
          <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
            <path
              d="M6.7 5.3 12 10.6l5.3-5.3 1.4 1.4L13.4 12l5.3 5.3-1.4 1.4L12 13.4l-5.3 5.3-1.4-1.4L10.6 12 5.3 6.7z"
              fill="currentColor"
            />
          </svg>
        </button>
      </div>
    </header>
  )
}
