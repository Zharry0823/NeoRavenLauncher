const listeners = { state: new Set(), log: new Set(), settings: new Set(), updates: new Set(), identified: new Set() }

function subscribe(channel, cb) {
  listeners[channel].add(cb)
  return () => listeners[channel].delete(cb)
}

const bridge = typeof window !== 'undefined' ? window.neoraven : undefined

/* 浏览器预览（无 Electron 环境）下的降级实现 */
const mock = {
  platform: 'win32',
  isElectron: false,
  getBootstrap: async () => ({
    settings: {
      accent: '#FF9BB2',
      iconColor: '#FF9BB2',
      rootDir: 'D:\\NeoRaven',
      gameDir: 'D:\\NeoRaven\\.minecraft',
      resourcePacksDir: 'D:\\NeoRaven\\.minecraft\\resourcepacks',
      savesDir: 'D:\\NeoRaven\\.minecraft\\saves',
      modsDir: 'D:\\NeoRaven\\.minecraft\\mods',
      javaPath: '',
      memoryMb: 4096,
      jvmArgs: '-XX:+UseG1GC -Dfile.encoding=UTF-8',
      fullscreen: false,
      username: 'Steve',
      userNamed: true,
      clientVersion: '1.0.0',
      autoUpdate: true,
      closeOnLaunch: false,
      autoJava: true
    },
    firstRun: false,
    hwid: 'demo00000000000000000000',
    hwidMasked: 'demo00…0000',
    updateState: {
      releases: [{ tag: '1.0.0', name: 'NeoRaven 1.0.0', publishedAt: '2026-10-25', jar: { name: 'NeoRaven1.0.0.jar', size: 7407366 } }],
      current: '1.0.0',
      latest: '1.0.0',
      updated: false,
      checking: false,
      error: null
    },
    app: { version: '1.0.0', electron: '33.0.0', platform: 'win32', arch: 'x64', material: 'blur' },
    java: { found: true, path: 'C:\\Program Files\\Java\\jre1.8.0_451\\bin\\java.exe', version: '1.8.0_451' }
  }),
  saveSettings: async (patch) => patch,
  setupUser: async () => ({ ok: true }),
  renameUser: async () => ({ ok: true }),
  checkUpdates: async () => ({ releases: [], current: '', latest: '', updated: false, checking: false }),
  selectVersion: async () => ({ ok: true }),
  applyIconColor: async () => ({ ok: true, shortcuts: 0 }),
  pickFolder: async () => null,
  pickJava: async () => null,
  detectJava: async () => ({ found: true, path: 'C:\\Program Files\\Java\\jre1.8.0_451\\bin\\java.exe', version: '1.8.0_451' }),
  openPath: async () => {},
  scanMods: async () => ({ count: 1, items: [{ name: 'NeoRaven.jar', size: 1387004 }] }),
  launch: async () => ({ ok: true }),
  cancel: async () => {},
  minimize: () => {},
  maximize: () => {},
  close: () => {},
  onState: (cb) => subscribe('state', cb),
  onLog: (cb) => subscribe('log', cb),
  onSettings: (cb) => subscribe('settings', cb),
  onUpdates: (cb) => subscribe('updates', cb),
  onIdentified: (cb) => subscribe('identified', cb)
}

const api = bridge
  ? {
      platform: bridge.platform,
      isElectron: true,
      getBootstrap: bridge.getBootstrap,
      saveSettings: bridge.saveSettings,
      setupUser: bridge.setupUser,
      renameUser: bridge.renameUser,
      checkUpdates: bridge.checkUpdates,
      selectVersion: bridge.selectVersion,
      applyIconColor: bridge.applyIconColor,
      pickFolder: bridge.pickFolder,
      pickJava: bridge.pickJava,
      detectJava: bridge.detectJava,
      openPath: bridge.openPath,
      scanMods: bridge.scanMods,
      launch: bridge.launch,
      cancel: bridge.cancel,
      minimize: bridge.minimize,
      maximize: bridge.maximize,
      close: bridge.close,
      onState: bridge.onState,
      onLog: bridge.onLog,
      onSettings: bridge.onSettings,
      onUpdates: bridge.onUpdates,
      onIdentified: bridge.onIdentified
    }
  : mock

export default api
