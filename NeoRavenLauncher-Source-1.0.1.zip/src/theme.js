/* NeoRavenLauncher — Material 3 深色平面主题
 * 动效遵循 Material motion：emphasized easing、200–300ms 时长 */
import { createTheme, alpha } from '@mui/material/styles'

export const MUI_COLORS = [
  { name: 'NeoRaven 粉', value: '#FF9BB2' },
  { name: 'Red', value: '#F2B8B5' },
  { name: 'Deep Orange', value: '#FFB59A' },
  { name: 'Orange', value: '#FFCC80' },
  { name: 'Amber', value: '#FFE082' },
  { name: 'Yellow', value: '#FFF59D' },
  { name: 'Lime', value: '#C5E1A5' },
  { name: 'Green', value: '#A5D6A7' },
  { name: 'Teal', value: '#80CBC4' },
  { name: 'Cyan', value: '#80DEEA' },
  { name: 'Light Blue', value: '#90CAF9' },
  { name: 'Blue', value: '#90CAF9' },
  { name: 'Indigo', value: '#9FA8DA' },
  { name: 'Purple', value: '#CE93D8' },
  { name: 'Deep Purple', value: '#B39DDB' },
  { name: 'Pink', value: '#F48FB1' }
]

/* Material 3 motion tokens */
export const MOTION = {
  emphasized: 'cubic-bezier(0.2, 0, 0, 1)',
  standard: 'cubic-bezier(0.2, 0, 0, 1)',
  decelerate: 'cubic-bezier(0.05, 0.7, 0.1, 1)',
  accelerate: 'cubic-bezier(0.3, 0, 0.8, 0.15)',
  short: '120ms',
  medium: '220ms',
  long: '320ms'
}

export function buildTheme(accent = '#FF9BB2', density = 1) {
  const a = accent
  return createTheme({
    palette: {
      mode: 'dark',
      primary: { main: a, contrastText: '#1a0d13' },
      secondary: { main: a, contrastText: '#1a0d13' },
      background: { default: 'transparent', paper: 'transparent' },
      text: {
        primary: 'rgba(255,255,255,0.92)',
        secondary: 'rgba(255,255,255,0.55)',
        disabled: 'rgba(255,255,255,0.28)'
      },
      divider: 'rgba(255,255,255,0.08)',
      action: { hover: 'rgba(255,255,255,0.06)', selected: alpha(a, 0.16) }
    },
    shape: { borderRadius: 16 },
    typography: {
      fontFamily: '"Inter", "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif',
      fontSize: 14 * (density || 1),
      button: { textTransform: 'none', fontWeight: 600, letterSpacing: 0.2 }
    },
    transitions: {
      duration: { shortest: 120, shorter: 180, short: 220, standard: 280, complex: 320 },
      easing: {
        easeOut: MOTION.emphasized,
        easeIn: MOTION.accelerate,
        easeInOut: MOTION.standard
      }
    },
    components: {
      MuiButton: {
        defaultProps: { disableElevation: true, disableRipple: false },
        styleOverrides: {
          root: {
            borderRadius: 100,
            padding: '9px 22px',
            fontSize: 14,
            transition: `background-color ${MOTION.medium} ${MOTION.emphasized}, transform ${MOTION.short} ${MOTION.emphasized}`
          },
          containedPrimary: {
            color: '#1a0d13',
            '&:active': { transform: 'scale(0.96)' }
          },
          outlined: {
            borderColor: alpha(a, 0.4),
            '&:active': { transform: 'scale(0.96)' }
          }
        }
      },
      MuiIconButton: {
        styleOverrides: {
          root: {
            borderRadius: 100,
            transition: `background-color ${MOTION.medium} ${MOTION.emphasized}, transform ${MOTION.short}`
          }
        }
      },
      MuiTextField: {
        defaultProps: { variant: 'standard', size: 'small' }
      },
      MuiSwitch: {
        styleOverrides: {
          root: { padding: 8 },
          switchBase: {
            '&.Mui-checked': {
              color: '#fff',
              '& + .MuiSwitch-track': { backgroundColor: a, opacity: 1 }
            }
          },
          track: { borderRadius: 100, backgroundColor: 'rgba(255,255,255,0.18)' },
          thumb: { backgroundColor: '#fff', boxShadow: 'none' }
        }
      },
      MuiSlider: {
        styleOverrides: {
          root: { height: 4 },
          thumb: { width: 16, height: 16, backgroundColor: a, boxShadow: 'none', '&:hover': { boxShadow: 'none' } },
          track: { backgroundColor: a, border: 'none', height: 4 },
          rail: { backgroundColor: 'rgba(255,255,255,0.12)', height: 4 }
        }
      },
      MuiTooltip: {
        styleOverrides: {
          tooltip: {
            backgroundColor: 'rgba(32,28,32,0.96)',
            borderRadius: 8,
            fontSize: 12,
            color: 'rgba(255,255,255,0.9)'
          }
        }
      }
    }
  })
}
